# PhutSmp 1.1.0

Features in this starter:
- `/sell`: GUI with a central item slot, lime stained glass confirm button, and $1 per item.
- `/balance` and `/eco balance`.
- Sidebar scoreboard: player name, balance, and playtime.
- `/shop` opens two category buttons (the category purchasing logic is not implemented yet).

Upload the contents of this project to a ZIP named `PhutSmp_CODE_v1.1.zip` at the repository root if using the included ZIP workflow. Or upload this project's files directly and build with Gradle.

Note: `/ah` and `/order` are currently placeholder responses in this version; their full auction/order functionality is not implemented in this update.
