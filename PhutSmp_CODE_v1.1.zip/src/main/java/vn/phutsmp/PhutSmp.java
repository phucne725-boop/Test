package vn.phutsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.util.*;

public final class PhutSmp extends JavaPlugin implements Listener {
    private static final String SELL_TITLE = ChatColor.DARK_GREEN + "Phut SMP | Sell";
    private static final String SHOP_TITLE = ChatColor.GOLD + "Phut SMP | Shop";
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<UUID, Long> joinedAt = new HashMap<>();
    private final Map<UUID, Long> playtimeMillis = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);

        Objects.requireNonNull(getCommand("sell")).setExecutor(this);
        Objects.requireNonNull(getCommand("ah")).setExecutor(this);
        Objects.requireNonNull(getCommand("order")).setExecutor(this);
        Objects.requireNonNull(getCommand("shop")).setExecutor(this);
        Objects.requireNonNull(getCommand("eco")).setExecutor(this);
        Objects.requireNonNull(getCommand("balance")).setExecutor(this);

        for (Player player : Bukkit.getOnlinePlayers()) {
            joinedAt.put(player.getUniqueId(), System.currentTimeMillis());
            updateScoreboard(player);
        }
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) updateScoreboard(player);
        }, 20L, 20L);

        getLogger().info("PhutSmp enabled successfully.");
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) recordSession(player);
        saveData();
    }

    private void loadData() {
        for (String key : getConfig().getConfigurationSection("balances") == null
                ? Collections.<String>emptySet()
                : getConfig().getConfigurationSection("balances").getKeys(false)) {
            try { balances.put(UUID.fromString(key), getConfig().getDouble("balances." + key)); }
            catch (IllegalArgumentException ignored) {}
        }
        for (String key : getConfig().getConfigurationSection("playtime") == null
                ? Collections.<String>emptySet()
                : getConfig().getConfigurationSection("playtime").getKeys(false)) {
            try { playtimeMillis.put(UUID.fromString(key), getConfig().getLong("playtime." + key)); }
            catch (IllegalArgumentException ignored) {}
        }
    }

    private void saveData() {
        getConfig().set("balances", null);
        getConfig().set("playtime", null);
        balances.forEach((id, amount) -> getConfig().set("balances." + id, amount));
        playtimeMillis.forEach((id, millis) -> getConfig().set("playtime." + id, millis));
        saveConfig();
    }

    private double balance(UUID id) { return balances.getOrDefault(id, 0.0); }

    private void setBalance(UUID id, double amount) {
        balances.put(id, Math.max(0, amount));
        saveData();
    }

    private void recordSession(Player player) {
        Long start = joinedAt.remove(player.getUniqueId());
        if (start != null) {
            playtimeMillis.merge(player.getUniqueId(), System.currentTimeMillis() - start, Long::sum);
        }
        saveData();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        joinedAt.put(event.getPlayer().getUniqueId(), System.currentTimeMillis());
        updateScoreboard(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        recordSession(event.getPlayer());
    }

    private String formatTime(long millis) {
        long seconds = Math.max(0, millis / 1000);
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        return hours + "h " + minutes + "m";
    }

    private void updateScoreboard(Player player) {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;
        Scoreboard board = manager.getNewScoreboard();
        Objective objective = board.registerNewObjective("phutsmp", "dummy",
                ChatColor.GOLD + "" + ChatColor.BOLD + "PHUT SMP");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        long total = playtimeMillis.getOrDefault(player.getUniqueId(), 0L);
        Long start = joinedAt.get(player.getUniqueId());
        if (start != null) total += System.currentTimeMillis() - start;

        objective.getScore(ChatColor.YELLOW + "Tên: " + ChatColor.WHITE + player.getName()).setScore(3);
        objective.getScore(ChatColor.GREEN + "Tiền: " + ChatColor.WHITE + "$" + trim(balance(player.getUniqueId()))).setScore(2);
        objective.getScore(ChatColor.AQUA + "Chơi: " + ChatColor.WHITE + formatTime(total)).setScore(1);
        player.setScoreboard(board);
    }

    private String trim(double value) {
        if (value == Math.floor(value)) return String.valueOf((long) value);
        return String.format(Locale.US, "%.2f", value);
    }

    private ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Arrays.asList(lore));
        stack.setItemMeta(meta);
        return stack;
    }

    private void openSell(Player player) {
        Inventory inv = Bukkit.createInventory(player, 45, SELL_TITLE);
        ItemStack pane = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 45; i++) {
            if (i != 13 && i != 29 && i != 31 && i != 33) inv.setItem(i, pane);
        }
        inv.setItem(13, item(Material.HOPPER, ChatColor.YELLOW + "Đặt vật phẩm muốn bán",
                ChatColor.GRAY + "Kéo vật phẩm từ túi đồ vào đây.",
                ChatColor.GRAY + "Giá bán: " + ChatColor.GREEN + "$1 mỗi vật phẩm"));
        inv.setItem(29, item(Material.RED_STAINED_GLASS_PANE, ChatColor.RED + "Hủy",
                ChatColor.GRAY + "Đóng GUI và trả vật phẩm."));
        inv.setItem(31, item(Material.LIME_STAINED_GLASS_PANE, ChatColor.GREEN + "" + ChatColor.BOLD + "XÁC NHẬN BÁN",
                ChatColor.GRAY + "Bấm để bán vật phẩm trong ô giữa.",
                ChatColor.GREEN + "$1 / vật phẩm"));
        inv.setItem(33, item(Material.PAPER, ChatColor.YELLOW + "Bảng giá",
                ChatColor.GRAY + "Mỗi vật phẩm bán được $1.",
                ChatColor.GRAY + "Số tiền nhận = số lượng vật phẩm."));
        player.openInventory(inv);
    }

    private void returnSellItems(Player player, Inventory inv) {
        ItemStack stored = inv.getItem(13);
        if (stored != null && !stored.getType().isAir()) {
            Map<Integer, ItemStack> leftovers = player.getInventory().addItem(stored);
            leftovers.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            inv.setItem(13, null);
        }
    }

    private void openShop(Player player) {
        Inventory inv = Bukkit.createInventory(player, 27, SHOP_TITLE);
        inv.setItem(11, item(Material.COOKED_BEEF, ChatColor.GOLD + "Thức ăn",
                ChatColor.GRAY + "Mở shop thức ăn (đang phát triển)."));
        inv.setItem(15, item(Material.END_CRYSTAL, ChatColor.LIGHT_PURPLE + "PvP Crystal",
                ChatColor.GRAY + "Mở shop PvP Crystal (đang phát triển)."));
        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();

        if (title.equals(SELL_TITLE)) {
            if (event.getClickedInventory() == null) return;

            // Allow placing/removing items only in the central GUI slot.
            if (event.getClickedInventory() == event.getView().getTopInventory()) {
                int slot = event.getSlot();
                if (slot == 13) {
                    event.setCancelled(false);
                    return;
                }
                event.setCancelled(true);
                if (slot == 29) {
                    returnSellItems(player, event.getView().getTopInventory());
                    player.closeInventory();
                } else if (slot == 31) {
                    ItemStack stored = event.getView().getTopInventory().getItem(13);
                    if (stored == null || stored.getType().isAir()
                            || stored.getType() == Material.HOPPER) {
                        player.sendMessage(ChatColor.RED + "Bạn chưa đặt vật phẩm vào ô bán!");
                        return;
                    }
                    int amount = stored.getAmount();
                    event.getView().getTopInventory().setItem(13, null);
                    setBalance(player.getUniqueId(), balance(player.getUniqueId()) + amount);
                    player.sendMessage(ChatColor.GREEN + "Đã bán " + amount
                            + " vật phẩm và nhận $" + amount + "!");
                    player.closeInventory();
                }
            } else {
                // Shift-click from player inventory into the sell slot.
                if (event.isShiftClick()) {
                    event.setCancelled(true);
                    ItemStack clicked = event.getCurrentItem();
                    if (clicked == null || clicked.getType().isAir()) return;
                    Inventory top = event.getView().getTopInventory();
                    ItemStack existing = top.getItem(13);
                    if (existing == null || existing.getType() == Material.HOPPER) {
                        top.setItem(13, clicked.clone());
                        event.getClickedInventory().setItem(event.getSlot(), null);
                    } else if (existing.isSimilar(clicked)
                            && existing.getAmount() + clicked.getAmount() <= existing.getMaxStackSize()) {
                        existing.setAmount(existing.getAmount() + clicked.getAmount());
                        event.getClickedInventory().setItem(event.getSlot(), null);
                    } else {
                        player.sendMessage(ChatColor.RED + "Ô bán đang chứa vật phẩm khác hoặc đã đầy.");
                    }
                }
            }
            return;
        }

        if (title.equals(SHOP_TITLE)) {
            event.setCancelled(true);
            if (event.getClickedInventory() != event.getView().getTopInventory()) return;
            if (event.getSlot() == 11 || event.getSlot() == 15) {
                player.sendMessage(ChatColor.YELLOW + "Danh mục shop này sẽ được bổ sung ở bản cập nhật tiếp theo.");
            }
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTitle().equals(SELL_TITLE)) {
            for (int raw : event.getRawSlots()) {
                if (raw < event.getView().getTopInventory().getSize() && raw != 13) {
                    event.setCancelled(true);
                    return;
                }
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        if (name.equals("eco")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("balance")) {
                if (sender instanceof Player p) sender.sendMessage(ChatColor.GREEN + "Số dư: $" + trim(balance(p.getUniqueId())));
                else sender.sendMessage("Lệnh này cần người chơi.");
                return true;
            }
            if ((args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("set"))
                    && sender.hasPermission("phutsmp.admin") && args.length >= 3) {
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                try {
                    double amount = Double.parseDouble(args[2]);
                    if (amount < 0) throw new NumberFormatException();
                    setBalance(target.getUniqueId(), args[0].equalsIgnoreCase("give")
                            ? balance(target.getUniqueId()) + amount : amount);
                    sender.sendMessage(ChatColor.GREEN + "Đã cập nhật tiền cho " + args[1]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(ChatColor.RED + "Số tiền không hợp lệ.");
                }
                return true;
            }
            sender.sendMessage(ChatColor.YELLOW + "/eco balance | /eco give <player> <amount> | /eco set <player> <amount>");
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Lệnh này chỉ dùng trong game.");
            return true;
        }

        switch (name) {
            case "sell" -> openSell(player);
            case "balance" -> player.sendMessage(ChatColor.GREEN + "Số dư: $" + trim(balance(player.getUniqueId())));
            case "ah" -> player.sendMessage(ChatColor.YELLOW + "Auction House sẽ được bổ sung sau. /ah");
            case "order" -> player.sendMessage(ChatColor.YELLOW + "Order sẽ được bổ sung sau. /order");
            case "shop" -> openShop(player);
            default -> { return false; }
        }
        return true;
    }
}
