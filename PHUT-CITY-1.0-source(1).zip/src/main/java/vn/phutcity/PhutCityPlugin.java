package vn.phutcity;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
import vn.phutcity.account.AccountManager;
import vn.phutcity.account.AccountCommand;
import vn.phutcity.account.AccountListener;

public final class PhutCityPlugin extends JavaPlugin {
    private AccountManager accounts;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.accounts = new AccountManager(this);
        AccountListener listener = new AccountListener(this, accounts);
        AccountCommand command = new AccountCommand(this, accounts, listener);
        getCommand("register").setExecutor(command);
        getCommand("login").setExecutor(command);
        getCommand("lock").setExecutor(command);
        getCommand("unlock").setExecutor(command);
        Bukkit.getPluginManager().registerEvents(listener, this);
        getLogger().info("PHỤT CITY đã khởi động. Bản nền tảng thử nghiệm.");
    }

    @Override
    public void onDisable() {
        if (accounts != null) accounts.save();
    }

    public void sendPrefix(org.bukkit.command.CommandSender sender, String message) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8[&bPHỤT CITY&8] &f" + message));
    }
}
