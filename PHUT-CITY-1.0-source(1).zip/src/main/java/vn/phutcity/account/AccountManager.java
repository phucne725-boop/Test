package vn.phutcity.account;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import vn.phutcity.PhutCityPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class AccountManager {
    private final PhutCityPlugin plugin;
    private final File file;
    private YamlConfiguration data;
    private final Set<UUID> authenticated = new HashSet<>();
    private final Set<UUID> lockedThisSession = new HashSet<>();
    private final SecureRandom random = new SecureRandom();

    public AccountManager(PhutCityPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "accounts.yml");
        if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    public boolean exists(UUID id) { return data.contains(path(id) + ".password"); }
    public boolean isAuthenticated(UUID id) { return authenticated.contains(id); }
    public boolean isLocked(UUID id) { return data.getBoolean(path(id) + ".locked", false); }
    public boolean isLockedSession(UUID id) { return lockedThisSession.contains(id); }

    public void register(UUID id, String password) {
        data.set(path(id) + ".password", hash(password));
        data.set(path(id) + ".locked", false);
        save();
    }

    public boolean checkPassword(UUID id, String password) {
        String stored = data.getString(path(id) + ".password", "");
        return !stored.isEmpty() && verify(stored, password);
    }

    public void authenticate(UUID id) { authenticated.add(id); }
    public void unauthenticate(UUID id) { authenticated.remove(id); }

    public boolean setLock(UUID id, String pin) {
        if (isLocked(id)) return false;
        data.set(path(id) + ".pin", hash(pin));
        data.set(path(id) + ".locked", true);
        lockedThisSession.add(id);
        save();
        return true;
    }

    public boolean unlock(UUID id, String pin) {
        if (!isLocked(id)) return false;
        String stored = data.getString(path(id) + ".pin", "");
        if (stored.isEmpty() || !verify(stored, pin)) return false;
        data.set(path(id) + ".locked", false);
        data.set(path(id) + ".pin", null);
        lockedThisSession.remove(id);
        save();
        return true;
    }

    public void onJoin(UUID id) {
        authenticated.remove(id);
        if (isLocked(id)) lockedThisSession.add(id);
    }

    public void onQuit(UUID id) {
        authenticated.remove(id);
        lockedThisSession.remove(id);
    }

    public void save() {
        try { data.save(file); }
        catch (IOException ex) { plugin.getLogger().severe("Không thể lưu accounts.yml: " + ex.getMessage()); }
    }

    private String path(UUID id) { return "players." + id; }

    // PBKDF2-HMAC-SHA256 with a unique random salt per credential.
    private String hash(String input) {
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        byte[] derived = derive(input, salt);
        return Base64.getEncoder().encodeToString(salt) + ":" +
                Base64.getEncoder().encodeToString(derived);
    }

    private boolean verify(String stored, String input) {
        try {
            String[] parts = stored.split(":", 2);
            if (parts.length != 2) return false;
            byte[] salt = Base64.getDecoder().decode(parts[0]);
            byte[] expected = Base64.getDecoder().decode(parts[1]);
            byte[] actual = derive(input, salt);
            return MessageDigest.isEqual(expected, actual);
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    private byte[] derive(String input, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(input.toCharArray(), salt, 210000, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } catch (Exception ex) {
            throw new IllegalStateException("Không thể băm thông tin đăng nhập", ex);
        } finally {
            spec.clearPassword();
        }
    }

}
