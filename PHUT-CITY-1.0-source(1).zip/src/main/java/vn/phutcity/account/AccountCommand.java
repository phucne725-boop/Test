package vn.phutcity.account;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import vn.phutcity.PhutCityPlugin;

public final class AccountCommand implements CommandExecutor {
    private final PhutCityPlugin plugin;
    private final AccountManager accounts;
    private final AccountListener listener;

    public AccountCommand(PhutCityPlugin plugin, AccountManager accounts, AccountListener listener) {
        this.plugin = plugin;
        this.accounts = accounts;
        this.listener = listener;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Lệnh này chỉ dành cho người chơi.");
            return true;
        }
        String name = command.getName().toLowerCase();
        switch (name) {
            case "register" -> {
                if (accounts.exists(player.getUniqueId())) return msg(player, "&cTài khoản đã tồn tại. Hãy đăng nhập.");
                if (args.length != 2) return msg(player, "&eDùng: /register <mật-khẩu> <nhập-lại>");
                if (args[0].length() < 6) return msg(player, "&cMật khẩu phải có ít nhất 6 ký tự.");
                if (!args[0].equals(args[1])) return msg(player, "&cHai mật khẩu không khớp.");
                accounts.register(player.getUniqueId(), args[0]);
                accounts.authenticate(player.getUniqueId());
                listener.refresh(player);
                return msg(player, "&aĐăng ký thành công! Chào mừng đến PHỤT CITY.");
            }
            case "login" -> {
                if (!accounts.exists(player.getUniqueId())) return msg(player, "&cBạn chưa có tài khoản. Dùng /register.");
                if (accounts.isAuthenticated(player.getUniqueId())) return msg(player, "&eBạn đã đăng nhập.");
                if (args.length != 1) return msg(player, "&eDùng: /login <mật-khẩu>");
                if (!accounts.checkPassword(player.getUniqueId(), args[0])) return msg(player, "&cMật khẩu không chính xác.");
                accounts.authenticate(player.getUniqueId());
                listener.refresh(player);
                if (accounts.isLocked(player.getUniqueId())) {
                    return msg(player, "&6Bạn đã đăng nhập. Tài khoản vẫn LOCK; dùng /unlock <PIN>.");
                }
                return msg(player, "&aĐăng nhập thành công!");
            }
            case "lock" -> {
                if (!accounts.isAuthenticated(player.getUniqueId())) return msg(player, "&cBạn phải đăng nhập trước.");
                if (accounts.isLocked(player.getUniqueId())) return msg(player, "&cTài khoản đã LOCK. Bạn phải /unlock trước; không thể LOCK lần nữa hoặc đổi PIN.");
                if (args.length != 1 || !args[0].matches("\\d{4,12}")) return msg(player, "&eDùng: /lock <PIN 4-12 chữ số>");
                accounts.setLock(player.getUniqueId(), args[0]);
                listener.refresh(player);
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', "&8[&bPHỤT CITY&8] &cTÀI KHOẢN ĐANG LOCK"));
                return true;
            }
            case "unlock" -> {
                if (!accounts.isAuthenticated(player.getUniqueId())) return msg(player, "&cBạn phải đăng nhập mật khẩu trước khi UNLOCK.");
                if (!accounts.isLocked(player.getUniqueId())) return msg(player, "&eTài khoản của bạn không LOCK.");
                if (args.length != 1) return msg(player, "&eDùng: /unlock <PIN>");
                if (!accounts.unlock(player.getUniqueId(), args[0])) return msg(player, "&cPIN không đúng.");
                listener.refresh(player);
                return msg(player, "&aMở khóa thành công! Bạn có thể tiếp tục chơi.");
            }
        }
        return true;
    }

    private boolean msg(Player player, String text) {
        plugin.sendPrefix(player, text);
        return true;
    }
}
