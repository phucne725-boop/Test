package vn.phutcity.account;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import vn.phutcity.PhutCityPlugin;

public final class AccountListener implements Listener {
    private final PhutCityPlugin plugin;
    private final AccountManager accounts;

    public AccountListener(PhutCityPlugin plugin, AccountManager accounts) {
        this.plugin = plugin;
        this.accounts = accounts;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        accounts.onJoin(player.getUniqueId());
        applyState(player);
        if (!accounts.exists(player.getUniqueId())) {
            plugin.sendPrefix(player, "&eBạn cần đăng ký: &b/register <mật-khẩu> <nhập-lại>");
        } else {
            plugin.sendPrefix(player, "&eVui lòng đăng nhập: &b/login <mật-khẩu>");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        accounts.onQuit(event.getPlayer().getUniqueId());
        for (Player other : plugin.getServer().getOnlinePlayers()) {
            other.showPlayer(plugin, event.getPlayer());
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;
        if (!accounts.isAuthenticated(event.getPlayer().getUniqueId())
                || accounts.isLocked(event.getPlayer().getUniqueId())) {
            Location from = event.getFrom();
            Location to = event.getTo();
            if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
                event.setTo(from);
            }
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player p = event.getPlayer();
        String raw = event.getMessage().toLowerCase();
        boolean auth = accounts.isAuthenticated(p.getUniqueId());
        boolean locked = accounts.isLocked(p.getUniqueId());
        if (!auth && !(raw.startsWith("/register ") || raw.equals("/register")
                || raw.startsWith("/login ") || raw.equals("/login"))) {
            event.setCancelled(true);
            plugin.sendPrefix(p, "&cBạn phải đăng nhập trước.");
        } else if (auth && locked && !(raw.startsWith("/unlock ") || raw.equals("/unlock"))) {
            event.setCancelled(true);
            plugin.sendPrefix(p, "&cTài khoản đang LOCK. Chỉ được dùng /unlock <PIN>.");
        }
    }

    @EventHandler public void onBreak(BlockBreakEvent e) { if (restricted(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onPlace(BlockPlaceEvent e) { if (restricted(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { if (restricted(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (restricted(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onPickup(EntityPickupItemEvent e) { if (e.getEntity() instanceof Player p && restricted(p)) e.setCancelled(true); }
    @EventHandler public void onDamage(EntityDamageEvent e) { if (e.getEntity() instanceof Player p && restricted(p)) e.setCancelled(true); }
    @EventHandler public void onInventory(InventoryClickEvent e) { if (e.getWhoClicked() instanceof Player p && restricted(p)) e.setCancelled(true); }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) { if (restricted(e.getPlayer())) e.setCancelled(true); }

    private boolean restricted(Player p) {
        return !accounts.isAuthenticated(p.getUniqueId()) || accounts.isLocked(p.getUniqueId());
    }

    public void refresh(Player player) {
        applyState(player);
    }

    private void applyState(Player player) {
        boolean locked = accounts.isLocked(player.getUniqueId());
        boolean unauth = !accounts.isAuthenticated(player.getUniqueId());
        if (locked || unauth) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 1, false, false, false));
            player.setInvulnerable(true);
            if (locked) {
                for (Player other : plugin.getServer().getOnlinePlayers()) {
                    if (!other.equals(player)) other.hidePlayer(plugin, player);
                }
            }
        } else {
            player.removePotionEffect(PotionEffectType.BLINDNESS);
            player.setInvulnerable(false);
            for (Player other : plugin.getServer().getOnlinePlayers()) other.showPlayer(plugin, player);
        }
    }

    @EventHandler
    public void onJoinVisibility(PlayerJoinEvent event) {
        Player joining = event.getPlayer();
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (accounts.isLocked(online.getUniqueId())) joining.hidePlayer(plugin, online);
        }
        if (accounts.isLocked(joining.getUniqueId())) {
            for (Player online : plugin.getServer().getOnlinePlayers()) online.hidePlayer(plugin, joining);
        }
    }
}
