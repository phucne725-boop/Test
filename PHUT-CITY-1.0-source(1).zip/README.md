# PHỤT CITY 1.0 — mã nguồn nền tảng

Đây là **bản nền tảng thử nghiệm**, chưa phải bản PHỤT CITY 1.0 hoàn chỉnh.

## Build
- Yêu cầu JDK 25 và Gradle 9.2.1 trở lên.
- Chạy: `gradle clean build`
- JAR nằm trong `build/libs/`.

## Đã triển khai trong bản nền tảng
- Lệnh đăng ký/đăng nhập cơ bản.
- Khóa di chuyển và thao tác khi chưa đăng nhập.
- `/lock <PIN>` và `/unlock <PIN>`.
- Không cho `/lock` lần hai khi tài khoản đang LOCK.
- Sau khi đăng nhập, tài khoản LOCK vẫn phải `/unlock`.
- Ẩn người chơi đang LOCK với người khác trong phiên.
- UTF-8 và thông báo tiếng Việt.

## Chưa hoàn thiện
Điện thoại, ngân hàng/ATM đầy đủ, công ty, NPC, bất động sản, bệnh viện, cảnh sát, bảng quản trị và các hệ thống thành phố khác chưa được triển khai trong ZIP này.

## Cảnh báo kỹ thuật
Đây là bản thử nghiệm cần kiểm thử và gia cố bảo mật trước khi dùng trên máy chủ thật. Cơ chế băm mật khẩu/PIN hiện là bản nền ban đầu, chưa đạt chuẩn bảo mật phát hành. Không dùng dữ liệu tài khoản thật.
