ECOCHILL v1.0 - SOURCE ZIP
==========================

Đây là mã nguồn plugin Maven, chưa phải file .jar đã biên dịch.
Mục tiêu build: Paper 26.3 + Java 25 (theo thông tin server bạn gửi).

CHỨC NĂNG
- /shop: giao diện 2 danh mục Food và Crystal PvP; giá mặc định $1/vật phẩm.
- /sell: mở GUI các loại vật phẩm trong túi; bấm vào một loại sẽ bán toàn bộ số lượng của loại đó với giá mặc định $1/item.
- /ah: xem chợ; /ah sell <giá-tổng> để đăng stack trên tay.
- /order: xem đơn mua; /order create <số-lượng> <giá-mỗi-item> khi cầm vật phẩm mẫu. Tiền được ký quỹ khi tạo order.
- /eco balance <player>, /eco give <player> <amount>, /eco set <player> <amount> (OP).
- Dữ liệu tiền, AH và order lưu trong plugins/EcoChill/config.yml.

CÀI ĐẶT / BUILD
1. Cần JDK 25 và Maven 3.9+ trên máy build.
2. Giải nén ZIP.
3. Mở terminal tại thư mục EcoChill, chạy: mvn clean package
4. File JAR tạo ra ở target/EcoChill-1.0.0.jar
5. Upload JAR vào thư mục plugins trên Jumping rồi restart server.

LƯU Ý QUAN TRỌNG
- Plugin dùng hệ thống tiền riêng, không cần Vault/EssentialsX. Đây là ví tiền độc lập của EcoChill.
- Giá mặc định của /sell và /shop là $1 mỗi item. Có thể sửa config.yml.
- /ah sell dùng giá tổng cho cả stack; /order create dùng giá mỗi item.
- Đây là bản nền v1.0 để test. Hãy chạy trên server test và backup server/dữ liệu trước khi cài server chính.
- Bản ZIP này chứa mã nguồn và cấu hình; chưa có .jar vì cần build với Paper API/JDK tương ứng.
