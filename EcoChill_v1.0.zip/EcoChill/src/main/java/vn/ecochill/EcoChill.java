package vn.ecochill;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class EcoChill extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<String, Listing> auctions = new LinkedHashMap<>();
    private final Map<String, BuyOrder> orders = new LinkedHashMap<>();
    private final Map<UUID, String> pendingSell = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig(); loadData();
        for (String cmd : List.of("ah", "order", "sell", "shop", "eco")) getCommand(cmd).setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("EcoChill v1.0 enabled.");
    }
    @Override public void onDisable() { saveData(); }

    private void loadData() {
        var c = getConfig();
        if (c.isConfigurationSection("balances")) for (String k : c.getConfigurationSection("balances").getKeys(false)) {
            try { balances.put(UUID.fromString(k), c.getDouble("balances." + k)); } catch (Exception ignored) {}
        }
        if (c.isConfigurationSection("auctions")) for (String id : c.getConfigurationSection("auctions").getKeys(false)) {
            String p = "auctions." + id;
            ItemStack item = c.getItemStack(p + ".item");
            if (item != null) auctions.put(id, new Listing(id, UUID.fromString(c.getString(p + ".owner")), c.getDouble(p + ".price"), item));
        }
        if (c.isConfigurationSection("orders")) for (String id : c.getConfigurationSection("orders").getKeys(false)) {
            String p = "orders." + id;
            ItemStack item = c.getItemStack(p + ".item");
            if (item != null) orders.put(id, new BuyOrder(id, UUID.fromString(c.getString(p + ".buyer")), c.getInt(p + ".amount"), c.getDouble(p + ".unit-price"), item));
        }
    }
    private void saveData() {
        var c = getConfig(); c.set("balances", null); c.set("auctions", null); c.set("orders", null);
        balances.forEach((id, amount) -> c.set("balances." + id, amount));
        auctions.forEach((id, a) -> { String p="auctions."+id; c.set(p+".owner",a.owner.toString()); c.set(p+".price",a.price); c.set(p+".item",a.item); });
        orders.forEach((id, o) -> { String p="orders."+id; c.set(p+".buyer",o.buyer.toString()); c.set(p+".amount",o.amount); c.set(p+".unit-price",o.unitPrice); c.set(p+".item",o.template); });
        saveConfig();
    }
    private double balance(UUID id) { return balances.computeIfAbsent(id, k -> getConfig().getDouble("starting-balance",100)); }
    private void deposit(UUID id,double n) { balances.put(id,balance(id)+n); }
    private boolean withdraw(UUID id,double n) { if (n < 0 || balance(id)+1e-8<n) return false; balances.put(id,balance(id)-n); return true; }
    private String money(double n) { return String.format(Locale.US,"$%.2f",n).replaceAll("\\.00$",""); }
    private ItemStack named(Material m,String name,String... lore) { ItemStack i=new ItemStack(m); ItemMeta meta=i.getItemMeta(); meta.setDisplayName("§e"+name); meta.setLore(Arrays.asList(lore)); i.setItemMeta(meta); return i; }
    private void open(Player p, Inventory inv) { p.openInventory(inv); }
    private Inventory menu(String title,int size) { return Bukkit.createInventory(null,size,"§8"+title); }
    private void fill(Inventory inv) { ItemStack pane=named(Material.GRAY_STAINED_GLASS_PANE," "); for(int x=0;x<inv.getSize();x++) if(inv.getItem(x)==null) inv.setItem(x,pane); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player) && !command.getName().equalsIgnoreCase("eco")) { sender.sendMessage("Players only."); return true; }
        Player p = sender instanceof Player pl ? pl : null;
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "ah" -> { if(args.length>=2 && args[0].equalsIgnoreCase("sell")) { if(p==null)return true; createAuction(p,args); } else if(p!=null) openAh(p); }
            case "order" -> { if(args.length>=1 && args[0].equalsIgnoreCase("create")) { if(p==null)return true; createOrder(p,args); } else if(p!=null) openOrders(p); }
            case "sell" -> { if(p!=null) openSell(p); }
            case "shop" -> { if(p!=null) openShop(p); }
            case "eco" -> ecoCommand(sender,args);
        }
        return true;
    }
    private void createAuction(Player p,String[] args) {
        if(args.length<2) { p.sendMessage("§eDùng: /ah sell <giá-tổng>"); return; }
        ItemStack hand=p.getInventory().getItemInMainHand(); if(hand.getType().isAir()) { p.sendMessage("§cCầm vật phẩm trên tay trước."); return; }
        double price; try { price=Double.parseDouble(args[1]); } catch(Exception e){p.sendMessage("§cGiá không hợp lệ.");return;}
        if(price<=0){p.sendMessage("§cGiá phải lớn hơn 0.");return;}
        String id=UUID.randomUUID().toString().substring(0,8); auctions.put(id,new Listing(id,p.getUniqueId(),price,hand.clone())); p.getInventory().setItemInMainHand(null);
        saveData(); p.sendMessage("§aĐã đăng " + hand.getAmount()+"x "+hand.getType()+" với giá "+money(price)+". Mã: "+id);
    }
    private void createOrder(Player p,String[] args) {
        if(args.length<3){p.sendMessage("§eDùng: /order create <số-lượng> <giá-mỗi-item> (cầm vật phẩm mẫu)");return;}
        ItemStack hand=p.getInventory().getItemInMainHand(); if(hand.getType().isAir()){p.sendMessage("§cCầm vật phẩm mẫu trên tay.");return;}
        int amount; double unit; try{amount=Integer.parseInt(args[1]);unit=Double.parseDouble(args[2]);}catch(Exception e){p.sendMessage("§cSố lượng/giá không hợp lệ.");return;}
        if(amount<1||unit<=0||unit*amount>100000000){p.sendMessage("§cThông số không hợp lệ.");return;}
        double total=amount*unit; if(!withdraw(p.getUniqueId(),total)){p.sendMessage("§cBạn cần "+money(total)+" để ký quỹ đơn hàng.");return;}
        String id=UUID.randomUUID().toString().substring(0,8); ItemStack template=hand.clone(); template.setAmount(1); orders.put(id,new BuyOrder(id,p.getUniqueId(),amount,unit,template)); saveData();
        p.sendMessage("§aĐã tạo order #"+id+". Đã ký quỹ "+money(total)+".");
    }
    private void openAh(Player p) {
        Inventory inv=menu("AUCTION HOUSE",54); int slot=0;
        for(Listing a:auctions.values()) { if(slot>=45)break; ItemStack i=a.item.clone(); ItemMeta m=i.getItemMeta(); List<String> lore=m.hasLore()?new ArrayList<>(m.getLore()):new ArrayList<>(); lore.add("§7Người bán: §f"+Bukkit.getOfflinePlayer(a.owner).getName()); lore.add("§7Giá tổng: §a"+money(a.price)); lore.add("§eBấm để xem/mua"); m.setLore(lore); i.setItemMeta(m); inv.setItem(slot++,i); }
        inv.setItem(49,named(Material.BARRIER,"Đóng")); fill(inv); open(p,inv);
    }
    private void openOrders(Player p) {
        Inventory inv=menu("PLAYER ORDERS",54); int slot=0;
        for(BuyOrder o:orders.values()){if(slot>=45)break; ItemStack i=o.template.clone(); ItemMeta m=i.getItemMeta(); m.setLore(List.of("§7Người mua: §f"+Bukkit.getOfflinePlayer(o.buyer).getName(),"§7Cần: §f"+o.amount,"§7Giá mỗi item: §a"+money(o.unitPrice),"§7Tổng ký quỹ: §a"+money(o.amount*o.unitPrice),"§eBấm để bán hàng cho order")); i.setItemMeta(m); inv.setItem(slot++,i);}
        inv.setItem(49,named(Material.BARRIER,"Đóng")); fill(inv); open(p,inv);
    }
    private void openSell(Player p) {
        Inventory inv=menu("SELL ITEMS - $1 EACH",54); int slot=0;
        for(ItemStack item:p.getInventory().getStorageContents()){if(item==null||item.getType().isAir())continue;if(slot>=45)break; ItemStack i=item.clone(); ItemMeta m=i.getItemMeta(); List<String> lore=m.hasLore()?new ArrayList<>(m.getLore()):new ArrayList<>(); lore.add("§7Giá mỗi vật phẩm: §a$1"); lore.add("§7Số lượng: §f"+item.getAmount()); lore.add("§7Tổng nhận: §a"+money(item.getAmount())); lore.add("§eBấm để bán cả stack này"); m.setLore(lore);i.setItemMeta(m);inv.setItem(slot++,i);}
        inv.setItem(49,named(Material.BARRIER,"Đóng")); fill(inv); open(p,inv);
    }
    private void openShop(Player p) {
        Inventory inv=menu("ECO CHILL SHOP",27);
        inv.setItem(11,named(Material.COOKED_BEEF,"FOOD SHOP","§7Thức ăn","§eBấm để mở"));
        inv.setItem(15,named(Material.END_CRYSTAL,"CRYSTAL PVP","§7Vật phẩm PvP","§eBấm để mở")); fill(inv); open(p,inv);
    }
    private void openCategory(Player p,String category) {
        List<String> mats=getConfig().getStringList("shop."+category); Inventory inv=menu(category.equals("food")?"FOOD SHOP":"CRYSTAL PVP SHOP",54); int slot=0;
        for(String s:mats){Material mat=Material.matchMaterial(s);if(mat==null||slot>=45)continue; ItemStack i=named(mat,pretty(mat),"§7Giá mỗi vật phẩm: §a"+money(getConfig().getDouble("shop-price-per-item",1)),"§eBấm để mua 1 vật phẩm");inv.setItem(slot++,i);}
        inv.setItem(49,named(Material.ARROW,"Quay lại"));fill(inv);open(p,inv);
    }
    private String pretty(Material m){String s=m.name().toLowerCase(Locale.ROOT).replace('_',' ');return Character.toUpperCase(s.charAt(0))+s.substring(1);}
    private void ecoCommand(CommandSender s,String[] a) {
        if(!s.hasPermission("ecochill.admin")){s.sendMessage("§cBạn không có quyền.");return;}
        if(a.length==0){s.sendMessage("§e/eco balance <player> | give <player> <amount> | set <player> <amount>");return;}
        if(a[0].equalsIgnoreCase("balance")&&a.length>=2){OfflinePlayer t=Bukkit.getOfflinePlayer(a[1]);s.sendMessage("§a"+t.getName()+": "+money(balance(t.getUniqueId())));return;}
        if((a[0].equalsIgnoreCase("give")||a[0].equalsIgnoreCase("set"))&&a.length>=3){OfflinePlayer t=Bukkit.getOfflinePlayer(a[1]);double n;try{n=Double.parseDouble(a[2]);}catch(Exception e){s.sendMessage("§cSố tiền không hợp lệ.");return;}if(n<0){s.sendMessage("§cSố tiền không hợp lệ.");return;}if(a[0].equalsIgnoreCase("give"))deposit(t.getUniqueId(),n);else balances.put(t.getUniqueId(),n);saveData();s.sendMessage("§aĐã cập nhật số dư "+t.getName()+": "+money(balance(t.getUniqueId())));return;}
        s.sendMessage("§e/eco balance <player> | give <player> <amount> | set <player> <amount>");
    }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if(!(e.getWhoClicked() instanceof Player p))return; String title=e.getView().getTitle();
        if(!title.startsWith("§8"))return; e.setCancelled(true); int slot=e.getRawSlot(); if(slot<0||slot>=e.getInventory().getSize())return;
        if(title.equals("§8AUCTION HOUSE")){ if(slot==49){p.closeInventory();return;} List<Listing> list=new ArrayList<>(auctions.values()); if(slot>=list.size())return; Listing a=list.get(slot); if(a.owner.equals(p.getUniqueId())){p.sendMessage("§cĐây là vật phẩm bạn đăng bán.");return;} if(!withdraw(p.getUniqueId(),a.price)){p.sendMessage("§cKhông đủ tiền. Cần "+money(a.price));return;} if(!p.getInventory().addItem(a.item.clone()).isEmpty()){deposit(p.getUniqueId(),a.price);p.sendMessage("§cTúi đồ đầy.");return;} auctions.remove(a.id); deposit(a.owner,a.price); saveData(); p.sendMessage("§aĐã mua vật phẩm với giá "+money(a.price)); p.closeInventory(); return; }
        if(title.equals("§8PLAYER ORDERS")){ if(slot==49){p.closeInventory();return;} List<BuyOrder> list=new ArrayList<>(orders.values());if(slot>=list.size())return;BuyOrder o=list.get(slot);if(o.buyer.equals(p.getUniqueId())){p.sendMessage("§cĐây là order của bạn.");return;} Player buyer=Bukkit.getPlayer(o.buyer); if(buyer==null){p.sendMessage("§cNgười đặt order đang offline. Hãy thử lại khi họ online.");return;} int have=countSimilar(p,o.template);if(have<=0){p.sendMessage("§cBạn không có vật phẩm phù hợp.");return;} int give=Math.min(have,o.amount); ItemStack delivery=o.template.clone(); delivery.setAmount(give); if(!buyer.getInventory().addItem(delivery).isEmpty()){p.sendMessage("§cTúi đồ người mua đã đầy. Giao dịch chưa thực hiện.");return;} removeSimilar(p,o.template,give); deposit(p.getUniqueId(),give*o.unitPrice); o.amount-=give; if(o.amount<=0)orders.remove(o.id); saveData();p.sendMessage("§aĐã giao "+give+" vật phẩm cho "+buyer.getName()+", nhận "+money(give*o.unitPrice));buyer.sendMessage("§aOrder của bạn đã được giao: "+give+"x "+pretty(o.template.getType()));p.closeInventory();return; }
        if(title.equals("§8SELL ITEMS - $1 EACH")){if(slot==49){p.closeInventory();return;} ItemStack displayed=e.getCurrentItem();if(displayed==null||displayed.getType().isAir())return; Material mat=displayed.getType();int count=0;for(ItemStack it:p.getInventory().getStorageContents())if(it!=null&&it.getType()==mat)count+=it.getAmount();if(count<=0)return;removeMaterial(p,mat,count);deposit(p.getUniqueId(),count);saveData();p.sendMessage("§aĐã bán "+count+"x "+pretty(mat)+" và nhận "+money(count));p.closeInventory();return;}
        if(title.equals("§8ECO CHILL SHOP")){if(slot==11)openCategory(p,"food");else if(slot==15)openCategory(p,"crystal-pvp");return;}
        if(title.equals("§8FOOD SHOP")||title.equals("§8CRYSTAL PVP SHOP")){if(slot==49){openShop(p);return;}ItemStack clicked=e.getCurrentItem();if(clicked==null||clicked.getType().isAir()||clicked.getType()==Material.GRAY_STAINED_GLASS_PANE)return;double price=getConfig().getDouble("shop-price-per-item",1);if(!withdraw(p.getUniqueId(),price)){p.sendMessage("§cKhông đủ tiền. Giá: "+money(price));return;}if(!p.getInventory().addItem(new ItemStack(clicked.getType(),1)).isEmpty()){deposit(p.getUniqueId(),price);p.sendMessage("§cTúi đồ đầy.");return;}saveData();p.sendMessage("§aĐã mua "+pretty(clicked.getType())+" với giá "+money(price));return;}
    }
    private int countSimilar(Player p,ItemStack template){int n=0;for(ItemStack i:p.getInventory().getStorageContents())if(i!=null&&i.isSimilar(template))n+=i.getAmount();return n;}
    private void removeSimilar(Player p,ItemStack template,int amount){for(int x=0;x<p.getInventory().getSize()&&amount>0;x++){ItemStack i=p.getInventory().getItem(x);if(i==null||!i.isSimilar(template))continue;int take=Math.min(amount,i.getAmount());i.setAmount(i.getAmount()-take);amount-=take;if(i.getAmount()<=0)p.getInventory().setItem(x,null);}}
    private void removeMaterial(Player p,Material mat,int amount){for(int x=0;x<p.getInventory().getStorageContents().length&&amount>0;x++){ItemStack i=p.getInventory().getItem(x);if(i==null||i.getType()!=mat)continue;int take=Math.min(amount,i.getAmount());i.setAmount(i.getAmount()-take);amount-=take;if(i.getAmount()<=0)p.getInventory().setItem(x,null);}}
    @EventHandler public void onClose(InventoryCloseEvent e) { /* GUI uses no movable contents */ }
    private record Listing(String id,UUID owner,double price,ItemStack item) {}
    private static final class BuyOrder { final String id; final UUID buyer; int amount; final double unitPrice; final ItemStack template; BuyOrder(String id,UUID buyer,int amount,double unitPrice,ItemStack template){this.id=id;this.buyer=buyer;this.amount=amount;this.unitPrice=unitPrice;this.template=template;} }
}
