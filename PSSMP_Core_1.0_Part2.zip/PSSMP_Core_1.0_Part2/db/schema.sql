CREATE TABLE IF NOT EXISTS pssmp_player_profiles (
  uuid CHAR(36) NOT NULL PRIMARY KEY,
  last_known_name VARCHAR(16) NOT NULL,
  playtime_seconds BIGINT UNSIGNED NOT NULL DEFAULT 0,
  first_joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_profile_name (last_known_name),
  INDEX idx_profile_last_seen (last_seen)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role and Discord-link tables are shared with API Part 1.
-- Do not create duplicate role/link tables in this module.
