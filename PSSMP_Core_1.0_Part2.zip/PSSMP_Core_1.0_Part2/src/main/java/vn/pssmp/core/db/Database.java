package vn.pssmp.core.db;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.Connection;
import java.sql.SQLException;

public final class Database implements AutoCloseable {
    private final JavaPlugin plugin;
    private HikariDataSource pool;

    public Database(JavaPlugin plugin) { this.plugin = plugin; }

    public synchronized void open() throws SQLException {
        if (pool != null && !pool.isClosed()) return;
        HikariConfig cfg = new HikariConfig();
        cfg.setJdbcUrl(plugin.getConfig().getString("database.jdbc-url"));
        cfg.setUsername(plugin.getConfig().getString("database.username"));
        cfg.setPassword(plugin.getConfig().getString("database.password"));
        cfg.setMaximumPoolSize(Math.max(2, plugin.getConfig().getInt("database.maximum-pool-size", 10)));
        cfg.setMinimumIdle(Math.max(1, plugin.getConfig().getInt("database.minimum-idle", 2)));
        cfg.setConnectionTimeout(Math.max(1000, plugin.getConfig().getLong("database.connection-timeout-ms", 5000)));
        cfg.setValidationTimeout(3000);
        cfg.setInitializationFailTimeout(10000);
        cfg.setPoolName("PSSMP-Core-MySQL");
        cfg.addDataSourceProperty("cachePrepStmts", "true");
        cfg.addDataSourceProperty("prepStmtCacheSize", "250");
        pool = new HikariDataSource(cfg);
        try (Connection c = pool.getConnection()) {
            if (!c.isValid(3)) throw new SQLException("MySQL validation failed");
        }
    }

    public Connection connection() throws SQLException {
        HikariDataSource current = pool;
        if (current == null || current.isClosed()) throw new SQLException("MySQL pool unavailable");
        Connection c = current.getConnection();
        if (!c.isValid(2)) {
            c.close();
            throw new SQLException("MySQL connection failed validation");
        }
        return c;
    }

    @Override public synchronized void close() {
        if (pool != null && !pool.isClosed()) pool.close();
    }
}
