package vn.pssmp.core.command;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import vn.pssmp.core.PSSMPCore;
import vn.pssmp.core.permission.PermissionManager;
import vn.pssmp.core.player.ProfileRepository;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class StatsCommand implements CommandExecutor {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")
            .withLocale(Locale.ROOT).withZone(ZoneId.of("Asia/Ho_Chi_Minh"));
    private final PSSMPCore plugin;
    private final ProfileRepository profiles;
    private final PermissionManager permissions;

    public StatsCommand(PSSMPCore plugin, ProfileRepository profiles, PermissionManager permissions) {
        this.plugin = plugin; this.profiles = profiles; this.permissions = permissions;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 1) { sender.sendMessage(ChatColor.RED + "Cách dùng: /stats [player]"); return true; }
        String target;
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Console dùng: /stats <player>"); return true;
            }
            target = player.getUniqueId().toString();
        } else target = args[0];

        sender.sendMessage(ChatColor.GRAY + "Đang tải thống kê...");
        profiles.findByNameOrUuid(target).whenComplete((result, error) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (sender instanceof Player p && !p.isOnline()) return;
                    if (error != null) { sender.sendMessage(plugin.message("database-unavailable")); return; }
                    if (result.isEmpty()) { sender.sendMessage(plugin.message("stats-not-found")); return; }
                    var profile = result.get();
                    String roles = permissions.getRoles(profile.uuid()).stream().map(Enum::name)
                            .sorted().reduce((a, b) -> a + ", " + b).orElse("Người chơi");
                    sender.sendMessage(plugin.message("stats-header").replace("%player%", profile.lastKnownName()));
                    sender.sendMessage(plugin.message("stats-playtime").replace("%playtime%", duration(profile.playtimeSeconds())));
                    sender.sendMessage(plugin.message("stats-joined").replace("%first_join%", DATE.format(profile.firstJoined())));
                    sender.sendMessage(plugin.message("stats-last-seen").replace("%last_seen%", DATE.format(profile.lastSeen())));
                    sender.sendMessage(plugin.message("stats-role").replace("%roles%", roles));
                }));
        return true;
    }

    private static String duration(long seconds) {
        long d = seconds / 86400, h = (seconds % 86400) / 3600, m = (seconds % 3600) / 60;
        return d + " ngày " + h + " giờ " + m + " phút";
    }
}
