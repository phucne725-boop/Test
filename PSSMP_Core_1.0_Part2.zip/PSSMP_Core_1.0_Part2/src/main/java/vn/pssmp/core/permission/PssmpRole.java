package vn.pssmp.core.permission;

public enum PssmpRole { ADMIN, HELPER, SPECTATOR, SYSTEM, DONATER, BOOSTER, MEDIA }
