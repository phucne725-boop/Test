package vn.pssmp.core.player;

import java.time.Instant;
import java.util.UUID;

public record PlayerProfile(UUID uuid, String lastKnownName, long playtimeSeconds,
                            Instant firstJoined, Instant lastSeen) {}
