package vn.pssmp.core.service;

import vn.pssmp.core.db.Database;
import vn.pssmp.core.permission.PermissionManager;
import vn.pssmp.core.player.ProfileRepository;

/** Shared service object for subsequent PSSMP gameplay modules. */
public final class PSSMPServices {
    private final Database database;
    private final ProfileRepository profiles;
    private final PermissionManager permissions;

    public PSSMPServices(Database database, ProfileRepository profiles, PermissionManager permissions) {
        this.database = database; this.profiles = profiles; this.permissions = permissions;
    }
    public Database database() { return database; }
    public ProfileRepository profiles() { return profiles; }
    public PermissionManager permissions() { return permissions; }
}
