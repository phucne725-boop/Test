# PSSMP Core 1.0 — Part 2

Substantive shared Core foundation (not placeholder files):
- Plugin lifecycle and validated configuration.
- HikariCP MySQL connection pool.
- UUID-based player profiles and playtime persistence.
- `/stats [player]`.
- Custom PSSMP role/permission manager (no LuckPerms).
- Discord role snapshot synchronization from API Part 1's MySQL table.
- Bukkit ServicesManager service for later gameplay modules.
- SQL schema, setup guide, integration contract and review report.

## Build
Requires JDK 25 and Maven 3.9+. Set `paper.version` in `pom.xml` to the exact Paper API artifact matching the server build before compiling:
`mvn clean package`

Output: `target/PSSMP-Core-1.0.jar`

## Install
1. Apply API Part 1 `db/schema.sql` and this part's `db/schema.sql` to the same MySQL database.
2. Configure `plugins/PSSMP-Core/config.yml`.
3. Install the JAR in `plugins/` and restart the server (do not use `/reload`).

This part does not pretend that Auth, Economy, AH, Order, Homes, Teams, Spawners, Crates, Tools, Lobby or Admin gameplay modules are complete. No fake placeholder commands are registered for them.
