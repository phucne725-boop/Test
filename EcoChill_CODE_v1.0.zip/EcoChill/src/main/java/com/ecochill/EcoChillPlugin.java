package com.ecochill;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class EcoChillPlugin extends JavaPlugin implements Listener {
    private YamlConfiguration data;
    private File dataFile;
    private final Map<Integer, String> auctionSlots = new HashMap<>();
    private final Map<Integer, String> orderSlots = new HashMap<>();
    private final Map<Integer, String> shopSlots = new HashMap<>();
    private final Map<UUID, String> pendingMenus = new HashMap<>();

    private static final String PREFIX = ChatColor.GREEN + "[EcoChill] " + ChatColor.GRAY;
    private static final String AH_TITLE = ChatColor.DARK_GREEN + "Auction House";
    private static final String ORDER_TITLE = ChatColor.DARK_AQUA + "Player Orders";
    private static final String SHOP_TITLE = ChatColor.DARK_GREEN + "EcoChill Shop";

    @Override public void onEnable() {
        saveDefaultConfig();
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("ah", "order", "sell", "shop", "eco")) {
            if (getCommand(name) != null) getCommand(name).setExecutor(this);
        }
        getLogger().info("EcoChill enabled. Commands: /ah /order /sell /shop /eco");
    }

    @Override public void onDisable() { saveData(); }

    private void saveData() {
        try { data.save(dataFile); } catch (IOException e) { getLogger().severe("Could not save data.yml: " + e.getMessage()); }
    }

    private double balance(UUID id) { return data.getDouble("balances." + id, getConfig().getDouble("starting-balance", 100.0)); }
    private void setBalance(UUID id, double amount) { data.set("balances." + id, Math.max(0, amount)); saveData(); }
    private void addBalance(UUID id, double amount) { setBalance(id, balance(id) + amount); }
    private boolean takeBalance(UUID id, double amount) {
        if (amount < 0 || balance(id) + 1.0E-9 < amount) return false;
        setBalance(id, balance(id) - amount); return true;
    }
    private String money(double amount) { return "$" + String.format(Locale.US, "%.2f", amount).replaceAll("\\.00$", ""); }
    private void msg(CommandSender sender, String text) { sender.sendMessage(PREFIX + text); }
    private ItemStack named(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) { meta.setDisplayName(ChatColor.GREEN + name); meta.setLore(lore); item.setItemMeta(meta); }
        return item;
    }
    private String nice(Material m) { return m.name().toLowerCase(Locale.ROOT).replace('_', ' '); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        if (cmd.equals("eco")) return ecoCommand(sender, args);
        if (!(sender instanceof Player p)) { msg(sender, "This command can only be used in-game."); return true; }
        switch (cmd) {
            case "ah" -> {
                if (args.length >= 1 && args[0].equalsIgnoreCase("sell")) {
                    if (args.length < 2) { msg(p, "Usage: /ah sell <total-price>"); return true; }
                    double price = parsePositive(args[1]);
                    if (price <= 0) { msg(p, "Price must be greater than 0."); return true; }
                    ItemStack hand = p.getInventory().getItemInMainHand();
                    if (hand.getType().isAir()) { msg(p, "Hold the item you want to list."); return true; }
                    String id = UUID.randomUUID().toString();
                    data.set("auctions." + id + ".seller", p.getUniqueId().toString());
                    data.set("auctions." + id + ".sellerName", p.getName());
                    data.set("auctions." + id + ".price", price);
                    data.set("auctions." + id + ".item", hand.clone());
                    p.getInventory().setItemInMainHand(null); saveData();
                    msg(p, "Listed " + hand.getAmount() + "x " + nice(hand.getType()) + " for " + money(price) + ".");
                } else openAuction(p);
                return true;
            }
            case "order" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("create")) {
                    if (args.length < 4) { msg(p, "Usage: /order create <MATERIAL> <amount> <price-per-item>"); return true; }
                    Material mat = Material.matchMaterial(args[1]);
                    int amount = parseInt(args[2]); double unit = parsePositive(args[3]);
                    if (mat == null || !mat.isItem() || mat.isAir() || amount < 1 || amount > 2304 || unit <= 0) { msg(p, "Invalid material, amount or price."); return true; }
                    double total = amount * unit;
                    if (!takeBalance(p.getUniqueId(), total)) { msg(p, "You need " + money(total) + " to escrow this order."); return true; }
                    String id = UUID.randomUUID().toString();
                    data.set("orders." + id + ".buyer", p.getUniqueId().toString());
                    data.set("orders." + id + ".buyerName", p.getName());
                    data.set("orders." + id + ".material", mat.name());
                    data.set("orders." + id + ".amount", amount);
                    data.set("orders." + id + ".unitPrice", unit);
                    saveData(); msg(p, "Order created: " + amount + "x " + nice(mat) + " at " + money(unit) + " each. Total escrow: " + money(total) + ".");
                } else openOrders(p);
                return true;
            }
            case "sell" -> { sellItems(p, args.length > 0 && args[0].equalsIgnoreCase("all")); return true; }
            case "shop" -> { openShop(p, "main"); return true; }
        }
        return false;
    }

    private boolean ecoCommand(CommandSender sender, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("balance")) {
            if (!(sender instanceof Player p)) { msg(sender, "Usage: /eco balance <player>"); return true; }
            msg(p, "Your balance: " + money(balance(p.getUniqueId()))); return true;
        }
        if (args[0].equalsIgnoreCase("pay") && sender instanceof Player p && args.length >= 3) {
            Player target = Bukkit.getPlayerExact(args[1]); double amount = parsePositive(args[2]);
            if (target == null || target.equals(p) || amount <= 0 || !takeBalance(p.getUniqueId(), amount)) { msg(p, "Invalid player, amount, or insufficient funds."); return true; }
            addBalance(target.getUniqueId(), amount); msg(p, "Paid " + target.getName() + " " + money(amount) + "."); msg(target, p.getName() + " paid you " + money(amount) + "."); return true;
        }
        if (args[0].matches("(?i)give|take|set") && sender.hasPermission("ecochill.admin") && args.length >= 3) {
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]); double amount = parsePositive(args[2]);
            if (!target.hasPlayedBefore() && !target.isOnline()) { msg(sender, "That player has never joined."); return true; }
            if (amount <= 0) { msg(sender, "Amount must be positive."); return true; }
            switch (args[0].toLowerCase(Locale.ROOT)) { case "give" -> addBalance(target.getUniqueId(), amount); case "take" -> setBalance(target.getUniqueId(), balance(target.getUniqueId()) - amount); case "set" -> setBalance(target.getUniqueId(), amount); }
            msg(sender, "Updated " + target.getName() + " balance to " + money(balance(target.getUniqueId())) + "."); return true;
        }
        msg(sender, "Usage: /eco balance | /eco pay <player> <amount> | /eco give|take|set <player> <amount>"); return true;
    }

    private void sellItems(Player p, boolean all) {
        double unit = getConfig().getDouble("sell-price", 1.0); int count = 0;
        if (!all) {
            ItemStack hand = p.getInventory().getItemInMainHand();
            if (hand.getType().isAir()) { msg(p, "Hold an item to sell, or use /sell all."); return; }
            count = hand.getAmount(); p.getInventory().setItemInMainHand(null);
        } else {
            for (int i = 0; i < p.getInventory().getStorageContents().length; i++) {
                ItemStack item = p.getInventory().getItem(i);
                if (item != null && !item.getType().isAir()) { count += item.getAmount(); p.getInventory().setItem(i, null); }
            }
        }
        if (count == 0) { msg(p, "No items to sell."); return; }
        double total = count * unit; addBalance(p.getUniqueId(), total); msg(p, "Sold " + count + " item(s) for " + money(total) + " (" + money(unit) + " each).");
    }

    private void openAuction(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, AH_TITLE); auctionSlots.clear();
        ConfigurationSection sec = data.getConfigurationSection("auctions"); int slot = 0;
        if (sec != null) for (String id : sec.getKeys(false)) {
            ItemStack item = data.getItemStack("auctions." + id + ".item"); if (item == null) continue;
            ItemStack display = item.clone(); ItemMeta meta = display.getItemMeta();
            List<String> lore = meta != null && meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
            lore.add(ChatColor.YELLOW + "Price: " + money(data.getDouble("auctions." + id + ".price")));
            lore.add(ChatColor.GRAY + "Seller: " + data.getString("auctions." + id + ".sellerName")); lore.add(ChatColor.GREEN + "Click to buy");
            if (meta != null) { meta.setLore(lore); display.setItemMeta(meta); }
            inv.setItem(slot, display); auctionSlots.put(slot, id); if (++slot >= 45) break;
        }
        inv.setItem(49, named(Material.BARRIER, "Close", List.of("Click to close")));
        p.openInventory(inv);
    }

    private void openOrders(Player p) {
        Inventory inv = Bukkit.createInventory(null, 54, ORDER_TITLE); orderSlots.clear();
        ConfigurationSection sec = data.getConfigurationSection("orders"); int slot = 0;
        if (sec != null) for (String id : sec.getKeys(false)) {
            Material mat = Material.matchMaterial(data.getString("orders." + id + ".material", "STONE")); if (mat == null) continue;
            int amount = data.getInt("orders." + id + ".amount"); double unit = data.getDouble("orders." + id + ".unitPrice");
            inv.setItem(slot, named(mat, amount + "x " + nice(mat), List.of(ChatColor.YELLOW + "Reward: " + money(unit) + " each", ChatColor.GRAY + "Buyer: " + data.getString("orders." + id + ".buyerName"), ChatColor.GREEN + "Click to fulfil")));
            orderSlots.put(slot, id); if (++slot >= 45) break;
        }
        inv.setItem(49, named(Material.BOOK, "Create an order", List.of("Use /order create <MATERIAL> <amount> <price-per-item>")));
        p.openInventory(inv);
    }

    private void openShop(Player p, String page) {
        Inventory inv = Bukkit.createInventory(null, 27, SHOP_TITLE); shopSlots.clear();
        if (page.equals("main")) {
            inv.setItem(11, named(Material.COOKED_BEEF, "Food Shop", List.of("Food and consumables", "Click to open")));
            inv.setItem(15, named(Material.END_CRYSTAL, "Crystal PvP Shop", List.of("Crystal PvP supplies", "Click to open")));
            shopSlots.put(11, "food"); shopSlots.put(15, "crystal");
        } else {
            List<Material> items = page.equals("food")
                    ? List.of(Material.COOKED_BEEF, Material.GOLDEN_CARROT, Material.BREAD, Material.COOKED_PORKCHOP, Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE, Material.BAKED_POTATO)
                    : List.of(Material.END_CRYSTAL, Material.OBSIDIAN, Material.RESPAWN_ANCHOR, Material.GLOWSTONE, Material.TOTEM_OF_UNDYING, Material.EXPERIENCE_BOTTLE);
            int slot = 10;
            for (Material mat : items) {
                inv.setItem(slot, named(mat, nice(mat), List.of(ChatColor.YELLOW + "Price: " + money(getConfig().getDouble("shop-price", 1.0)) + " each", ChatColor.GREEN + "Click to buy 1")));
                shopSlots.put(slot, "buy:" + mat.name()); slot++; if (slot == 17) slot = 19;
            }
            inv.setItem(22, named(Material.ARROW, "Back", List.of("Return to categories"))); shopSlots.put(22, "back");
        }
        p.openInventory(inv);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String title = e.getView().getTitle();
        if (!title.equals(AH_TITLE) && !title.equals(ORDER_TITLE) && !title.equals(SHOP_TITLE)) return;
        e.setCancelled(true); if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();
        if (title.equals(AH_TITLE)) {
            String id = auctionSlots.get(slot); if (id == null) { if (slot == 49) p.closeInventory(); return; }
            String path = "auctions." + id; ItemStack item = data.getItemStack(path + ".item"); double price = data.getDouble(path + ".price");
            if (item == null) { msg(p, "This listing is no longer available."); openAuction(p); return; }
            if (p.getUniqueId().toString().equals(data.getString(path + ".seller"))) { msg(p, "You cannot buy your own listing."); return; }
            if (!takeBalance(p.getUniqueId(), price)) { msg(p, "You need " + money(price) + " to buy this."); return; }
            Map<Integer, ItemStack> leftover = p.getInventory().addItem(item.clone());
            if (!leftover.isEmpty()) { addBalance(p.getUniqueId(), price); msg(p, "Your inventory is full."); return; }
            UUID seller = UUID.fromString(data.getString(path + ".seller")); addBalance(seller, price); data.set(path, null); saveData();
            msg(p, "Purchased item for " + money(price) + "."); Player online = Bukkit.getPlayer(seller); if (online != null) msg(online, "Your auction sold for " + money(price) + "."); openAuction(p);
        } else if (title.equals(ORDER_TITLE)) {
            String id = orderSlots.get(slot); if (id == null) return;
            String path = "orders." + id; Material mat = Material.matchMaterial(data.getString(path + ".material", "STONE")); int amount = data.getInt(path + ".amount"); double unit = data.getDouble(path + ".unitPrice");
            if (mat == null) return;
            int available = 0; for (ItemStack it : p.getInventory().getStorageContents()) if (it != null && it.getType() == mat) available += it.getAmount();
            if (available < amount) { msg(p, "You need " + amount + "x " + nice(mat) + " to fulfil this order."); return; }
            int remaining = amount;
            for (int i = 0; i < p.getInventory().getStorageContents().length && remaining > 0; i++) {
                ItemStack it = p.getInventory().getItem(i); if (it == null || it.getType() != mat) continue;
                int take = Math.min(remaining, it.getAmount()); it.setAmount(it.getAmount() - take); if (it.getAmount() <= 0) p.getInventory().setItem(i, null); remaining -= take;
            }
            UUID buyer = UUID.fromString(data.getString(path + ".buyer")); double total = amount * unit; addBalance(p.getUniqueId(), total);
            data.set(path, null); saveData(); msg(p, "Order fulfilled. You received " + money(total) + "."); Player buyerPlayer = Bukkit.getPlayer(buyer); if (buyerPlayer != null) msg(buyerPlayer, "Your order was fulfilled by " + p.getName() + "."); openOrders(p);
        } else {
            String action = shopSlots.get(slot); if (action == null) return;
            if (action.equals("food") || action.equals("crystal")) openShop(p, action);
            else if (action.equals("back")) openShop(p, "main");
            else if (action.startsWith("buy:")) {
                Material mat = Material.matchMaterial(action.substring(4)); if (mat == null) return;
                double price = getConfig().getDouble("shop-price", 1.0);
                if (!takeBalance(p.getUniqueId(), price)) { msg(p, "You need " + money(price) + "."); return; }
                Map<Integer, ItemStack> leftover = p.getInventory().addItem(new ItemStack(mat, 1));
                if (!leftover.isEmpty()) { addBalance(p.getUniqueId(), price); msg(p, "Your inventory is full."); return; }
                msg(p, "Bought 1x " + nice(mat) + " for " + money(price) + "."); p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
            }
        }
    }

    private double parsePositive(String s) { try { double d = Double.parseDouble(s); return Double.isFinite(d) && d > 0 ? d : -1; } catch (Exception e) { return -1; } }
    private int parseInt(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return -1; } }
}
