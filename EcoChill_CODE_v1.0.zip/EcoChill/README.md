# EcoChill v1.0

A real Paper plugin source project with `/ah`, `/order`, `/sell`, `/shop`, and `/eco`.

## Build with GitHub Actions
1. Upload the contents of this folder to the root of a GitHub repository (keep the `.github` folder).
2. Open Actions and run **Build EcoChill** (or push to `main`).
3. Download the `EcoChill-JAR` artifact and put `EcoChill-1.0.0.jar` in the server's `plugins` folder.

## Commands
- `/ah` - browse auction listings.
- `/ah sell <total-price>` - list the item in your main hand for a total price.
- `/order` - browse player buy orders.
- `/order create <MATERIAL> <amount> <price-per-item>` - create an escrow-funded order.
- `/sell` - sell the item in your main hand at configured sell-price per item.
- `/sell all` - sell all non-empty storage inventory items at configured sell-price per item.
- `/shop` - Food and Crystal PvP categories; each shop item costs configured shop-price.
- `/eco balance` - check balance; `/eco pay <player> <amount>`; admins: `/eco give|take|set <player> <amount>`.

Balances, auctions, and orders are stored in `plugins/EcoChill/data.yml`.

## Notes
- The plugin has its own simple economy; Vault/EssentialsX is not required.
- Defaults: starting balance 100, sell price $1 per item, shop price $1 per item.
- Auction price is the total price for the listed stack. Order price is per item and is escrowed when created.
- Test on a backup/test server before using on a live economy server.
- The workflow compiles against the Paper API version reported by the server: `26.3.build.244-stable` and uses Java 25.
