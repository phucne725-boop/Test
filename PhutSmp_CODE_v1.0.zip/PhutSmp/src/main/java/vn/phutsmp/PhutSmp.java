package vn.phutsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class PhutSmp extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Double> balances = new HashMap<>();
    private final List<Listing> auctions = new ArrayList<>();
    private final List<Order> orders = new ArrayList<>();
    private NamespacedKey actionKey;

    @Override public void onEnable() {
        saveDefaultConfig();
        actionKey = new NamespacedKey(this, "action");
        loadData();
        for (String cmd : List.of("ah", "order", "sell", "shop", "eco")) {
            Objects.requireNonNull(getCommand(cmd), "Missing command " + cmd).setExecutor(this);
        }
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("PhutSmp enabled. Commands: /ah /order /sell /shop /eco");
    }

    @Override public void onDisable() { saveData(); }

    private void loadData() {
        var c = getConfig();
        if (c.isConfigurationSection("balances")) for (String k : Objects.requireNonNull(c.getConfigurationSection("balances")).getKeys(false)) {
            try { balances.put(UUID.fromString(k), c.getDouble("balances." + k)); } catch (Exception ignored) {}
        }
        for (String s : c.getStringList("auctions")) {
            try { String[] p=s.split("\\|",4); auctions.add(new Listing(UUID.fromString(p[0]), Double.parseDouble(p[1]), Material.valueOf(p[2]), Integer.parseInt(p[3]))); } catch(Exception ignored) {}
        }
        for (String s : c.getStringList("orders")) {
            try { String[] p=s.split("\\|",4); orders.add(new Order(UUID.fromString(p[0]), Double.parseDouble(p[1]), Material.valueOf(p[2]), Integer.parseInt(p[3]))); } catch(Exception ignored) {}
        }
    }
    private void saveData() {
        var c = getConfig(); c.set("balances", null); c.set("auctions", null); c.set("orders", null);
        for (var e : balances.entrySet()) c.set("balances." + e.getKey(), e.getValue());
        List<String> a=new ArrayList<>(); for(Listing x:auctions) a.add(x.owner+"|"+x.price+"|"+x.type+"|"+x.amount); c.set("auctions",a);
        List<String> o=new ArrayList<>(); for(Order x:orders) o.add(x.owner+"|"+x.price+"|"+x.type+"|"+x.amount); c.set("orders",o);
        saveConfig();
    }
    private double money(UUID id) { return balances.getOrDefault(id, 0.0); }
    private void setMoney(UUID id,double v) { balances.put(id, Math.max(0,v)); saveData(); }
    private String fmt(double n) { return String.format(Locale.US,"%.2f",n); }
    private ItemStack named(Material m,String name,String... lore) {
        ItemStack it=new ItemStack(m); ItemMeta meta=it.getItemMeta(); meta.setDisplayName(ChatColor.GOLD+name);
        List<String> lines=new ArrayList<>(); for(String s:lore) lines.add(ChatColor.GRAY+s); meta.setLore(lines); it.setItemMeta(meta); return it;
    }
    private void tag(ItemStack it,String action) { ItemMeta m=it.getItemMeta(); m.getPersistentDataContainer().set(actionKey,PersistentDataType.STRING,action); it.setItemMeta(m); }
    private void openShop(Player p,String category) {
        Inventory inv=Bukkit.createInventory(null,54,ChatColor.DARK_GREEN+"Phut SMP » "+category);
        Material[] food={Material.COOKED_BEEF,Material.GOLDEN_CARROT,Material.BREAD,Material.GOLDEN_APPLE,Material.COOKED_PORKCHOP,Material.BAKED_POTATO,Material.COOKED_CHICKEN,Material.COOKED_COD};
        Material[] crystal={Material.END_CRYSTAL,Material.OBSIDIAN,Material.RESPAWN_ANCHOR,Material.GLOWSTONE,Material.TOTEM_OF_UNDYING,Material.EXPERIENCE_BOTTLE};
        Material[] items=category.equals("Food Shop")?food:crystal;
        for(Material m:items){ ItemStack it=named(m,pretty(m),"Giá: $1 / item","Bấm để mua 1; Shift + bấm để mua 64"); tag(it,"buy:"+m.name()); inv.addItem(it); }
        p.openInventory(inv);
    }
    private String pretty(Material m){ String s=m.name().toLowerCase(Locale.ROOT).replace('_',' '); return Character.toUpperCase(s.charAt(0))+s.substring(1); }
    private void openMainShop(Player p){ Inventory inv=Bukkit.createInventory(null,27,ChatColor.DARK_GREEN+"Phut SMP Shop"); inv.setItem(11,named(Material.COOKED_BEEF,"Food Shop","Thức ăn","Chọn để mở cửa hàng")); inv.setItem(15,named(Material.END_CRYSTAL,"Crystal PvP","Vật phẩm PvP","Chọn để mở cửa hàng")); p.openInventory(inv); }
    private void openAuctions(Player p){ Inventory inv=Bukkit.createInventory(null,54,ChatColor.DARK_AQUA+"Phut SMP Auction");
        for(int i=0;i<Math.min(auctions.size(),45);i++){ Listing l=auctions.get(i); ItemStack it=new ItemStack(l.type,Math.max(1,Math.min(64,l.amount))); ItemMeta m=it.getItemMeta(); m.setDisplayName(ChatColor.GOLD+pretty(l.type)); m.setLore(List.of(ChatColor.GRAY+"Người bán: "+Bukkit.getOfflinePlayer(l.owner).getName(),ChatColor.GREEN+"Giá: $"+fmt(l.price),ChatColor.YELLOW+"Bấm để mua")); it.setItemMeta(m); tag(it,"auction:"+i); inv.setItem(i,it); }
        p.openInventory(inv);
    }
    private void openOrders(Player p){ Inventory inv=Bukkit.createInventory(null,54,ChatColor.DARK_PURPLE+"Phut SMP Orders");
        for(int i=0;i<Math.min(orders.size(),45);i++){ Order o=orders.get(i); ItemStack it=new ItemStack(o.type,Math.max(1,Math.min(64,o.amount))); ItemMeta m=it.getItemMeta(); m.setDisplayName(ChatColor.LIGHT_PURPLE+pretty(o.type)); m.setLore(List.of(ChatColor.GRAY+"Người đặt: "+Bukkit.getOfflinePlayer(o.owner).getName(),ChatColor.GREEN+"Giá mỗi item: $"+fmt(o.price),ChatColor.YELLOW+"Bấm để giao hàng")); it.setItemMeta(m); tag(it,"order:"+i); inv.setItem(i,it); }
        p.openInventory(inv);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd=command.getName().toLowerCase(Locale.ROOT);
        if(cmd.equals("eco")) return eco(sender,args);
        if(!(sender instanceof Player p)){ sender.sendMessage("Players only."); return true; }
        switch(cmd){
            case "ah" -> { if(args.length==2 && args[0].equalsIgnoreCase("sell")){ double price=parse(args[1]); ItemStack hand=p.getInventory().getItemInMainHand(); if(price<=0||hand.getType().isAir()){p.sendMessage(ChatColor.RED+"Dùng: /ah sell <giá>, cầm vật phẩm trên tay.");return true;} auctions.add(new Listing(p.getUniqueId(),price,hand.getType(),hand.getAmount())); p.getInventory().setItemInMainHand(null); saveData(); p.sendMessage(ChatColor.GREEN+"Đã đăng bán "+hand.getAmount()+"x "+pretty(hand.getType())+" với giá $"+fmt(price)+"."); } else openAuctions(p); }
            case "order" -> { if(args.length>=2 && args[0].equalsIgnoreCase("create")){ double price=parse(args[1]); ItemStack hand=p.getInventory().getItemInMainHand(); if(price<=0||hand.getType().isAir()){p.sendMessage(ChatColor.RED+"Dùng: /order create <giá-mỗi-item>, cầm vật phẩm trên tay.");return true;} orders.add(new Order(p.getUniqueId(),price,hand.getType(),hand.getAmount())); saveData(); p.sendMessage(ChatColor.GREEN+"Đã tạo order mua "+hand.getAmount()+"x "+pretty(hand.getType())+" với giá $"+fmt(price)+"/item."); } else if(args.length==1&&args[0].equalsIgnoreCase("cancel")){ orders.removeIf(o->o.owner.equals(p.getUniqueId())); saveData(); p.sendMessage(ChatColor.YELLOW+"Đã hủy các order của bạn."); } else openOrders(p); }
            case "sell" -> sell(p,args);
            case "shop" -> openMainShop(p);
        }
        return true;
    }
    private boolean sell(Player p,String[] args){ int total=0; if(args.length>0&&args[0].equalsIgnoreCase("all")){ for(int i=0;i<p.getInventory().getStorageContents().length;i++){ItemStack it=p.getInventory().getItem(i); if(it!=null&&!it.getType().isAir()){total+=it.getAmount();p.getInventory().setItem(i,null);}} } else {ItemStack it=p.getInventory().getItemInMainHand(); if(it.getType().isAir()){p.sendMessage(ChatColor.RED+"Cầm vật phẩm muốn bán trên tay.");return true;} total=it.getAmount();p.getInventory().setItemInMainHand(null);} if(total>0){setMoney(p.getUniqueId(),money(p.getUniqueId())+total);p.sendMessage(ChatColor.GREEN+"Đã bán "+total+" vật phẩm, nhận $"+total+" ($1/item).");} return true; }
    private boolean eco(CommandSender s,String[] a){ if(a.length==0||a[0].equalsIgnoreCase("balance")){ if(s instanceof Player p)s.sendMessage(ChatColor.GREEN+"Số dư: $"+fmt(money(p.getUniqueId()))); else s.sendMessage("Use /eco give|set <player> <amount>"); return true; }
        if(a[0].equalsIgnoreCase("pay")&&s instanceof Player p&&a.length==3){Player t=Bukkit.getPlayerExact(a[1]);double n=parse(a[2]);if(t==null||n<=0||money(p.getUniqueId())<n){p.sendMessage(ChatColor.RED+"Người chơi không hợp lệ hoặc không đủ tiền.");return true;}setMoney(p.getUniqueId(),money(p.getUniqueId())-n);setMoney(t.getUniqueId(),money(t.getUniqueId())+n);p.sendMessage(ChatColor.GREEN+"Đã chuyển $"+fmt(n)+" cho "+t.getName());t.sendMessage(ChatColor.GREEN+"Bạn nhận được $"+fmt(n));return true;}
        if((a[0].equalsIgnoreCase("give")||a[0].equalsIgnoreCase("set"))&&s.hasPermission("phutsmp.admin")&&a.length==3){Player t=Bukkit.getPlayerExact(a[1]);double n=parse(a[2]);if(t==null||n<0){s.sendMessage("Player must be online and amount valid.");return true;}setMoney(t.getUniqueId(),a[0].equalsIgnoreCase("give")?money(t.getUniqueId())+n:n);s.sendMessage("Updated balance for "+t.getName());return true;}
        s.sendMessage(ChatColor.YELLOW+"/eco balance | /eco pay <player> <amount> | /eco give|set <player> <amount>");return true;
    }
    private double parse(String s){try{return Double.parseDouble(s);}catch(Exception e){return -1;}}

    @EventHandler public void onClick(InventoryClickEvent e){ if(!(e.getWhoClicked() instanceof Player p)||e.getView().getTitle()==null)return; String title=e.getView().getTitle(); if(!title.contains("Phut SMP"))return; e.setCancelled(true); ItemStack clicked=e.getCurrentItem(); if(clicked==null||clicked.getType().isAir())return;
        if(title.equals(ChatColor.DARK_GREEN+"Phut SMP Shop")){ if(clicked.getType()==Material.COOKED_BEEF)openShop(p,"Food Shop"); else if(clicked.getType()==Material.END_CRYSTAL)openShop(p,"Crystal PvP"); return; }
        ItemMeta meta=clicked.getItemMeta(); if(meta==null)return; String action=meta.getPersistentDataContainer().get(actionKey,PersistentDataType.STRING); if(action==null)return;
        if(action.startsWith("buy:")){Material m=Material.valueOf(action.substring(4));int amount=e.isShiftClick()?64:1;double cost=amount;if(money(p.getUniqueId())<cost){p.sendMessage(ChatColor.RED+"Bạn không đủ tiền. Cần $"+fmt(cost));return;} if(p.getInventory().firstEmpty()==-1){p.sendMessage(ChatColor.RED+"Túi đồ đã đầy.");return;}setMoney(p.getUniqueId(),money(p.getUniqueId())-cost);p.getInventory().addItem(new ItemStack(m,amount));p.sendMessage(ChatColor.GREEN+"Đã mua "+amount+"x "+pretty(m)+" với giá $"+fmt(cost));return;}
        if(action.startsWith("auction:")){int i=Integer.parseInt(action.substring(8));if(i<0||i>=auctions.size())return;Listing l=auctions.get(i);if(l.owner.equals(p.getUniqueId())){p.sendMessage(ChatColor.RED+"Bạn không thể tự mua vật phẩm của mình.");return;}if(money(p.getUniqueId())<l.price||p.getInventory().firstEmpty()==-1){p.sendMessage(ChatColor.RED+"Không đủ tiền hoặc túi đồ đầy.");return;}setMoney(p.getUniqueId(),money(p.getUniqueId())-l.price);setMoney(l.owner,money(l.owner)+l.price);p.getInventory().addItem(new ItemStack(l.type,l.amount));auctions.remove(i);saveData();p.sendMessage(ChatColor.GREEN+"Mua thành công!");p.closeInventory();openAuctions(p);return;}
        if(action.startsWith("order:")){int i=Integer.parseInt(action.substring(6));if(i<0||i>=orders.size())return;Order o=orders.get(i);if(o.owner.equals(p.getUniqueId())){p.sendMessage(ChatColor.RED+"Đây là order của bạn.");return;}ItemStack hand=p.getInventory().getItemInMainHand();if(hand.getType()!=o.type||hand.getAmount()<o.amount){p.sendMessage(ChatColor.RED+"Cầm đủ "+o.amount+"x "+pretty(o.type)+" trên tay để giao.");return;}double total=o.price*o.amount;if(money(o.owner)<total){p.sendMessage(ChatColor.RED+"Người đặt không đủ tiền.");return;}hand.setAmount(hand.getAmount()-o.amount);setMoney(o.owner,money(o.owner)-total);setMoney(p.getUniqueId(),money(p.getUniqueId())+total);orders.remove(i);saveData();p.sendMessage(ChatColor.GREEN+"Đã giao order, nhận $"+fmt(total));p.closeInventory();openOrders(p);}
    }
    private record Listing(UUID owner,double price,Material type,int amount){}
    private record Order(UUID owner,double price,Material type,int amount){}
}
