# PhutSmp 1.0.0

Paper plugin source for Phut SMP.

## Build with GitHub Actions
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open **Actions** → **Build PhutSmp** → **Run workflow**.
3. Download the `PhutSmp-JAR` artifact.
4. Put `PhutSmp-1.0.0.jar` into the server's `plugins/` folder and restart.

## Commands
- `/ah` — open auction house. `/ah sell <price>` lists the item in your main hand.
- `/order` — open the order board. `/order create <price>` creates a buy order for the item in your main hand; `/order cancel` cancels your order.
- `/sell` — sell the item in your main hand for $1 per item. `/sell all` sells all sellable items in inventory for $1 each.
- `/shop` — open Food / Crystal PvP shop. Click an item to buy one; shift-click buys a stack.
- `/eco balance` — show balance. `/eco pay <player> <amount>`. Admin: `/eco give <player> <amount>`, `/eco set <player> <amount>`.

## Notes
- This is an initial functional implementation with a simple internal economy stored in `plugins/PhutSmp/data.yml`.
- Auction and order listings are stored in the same data file.
- Test on a backup/test server before using it on a live economy.
