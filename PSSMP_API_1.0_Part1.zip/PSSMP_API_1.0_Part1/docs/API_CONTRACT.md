# PSSMP API Contract 1.0

All IDs are strings. Never parse Discord snowflakes into JavaScript floating-point numbers.

## Authentication
Every `/v1/*` request requires HMAC headers. Signature payload is exactly:
`timestamp + "\n" + nonce + "\n" + rawBody`

Use a cryptographically secure random nonce. Never reuse one. Timestamp must be within configured skew.

## Link create
`POST /v1/link/create`
```json
{"minecraftUuid":"00000000-0000-0000-0000-000000000000"}
```
Returns one-time 6-digit code and expiry timestamp. Store only SHA-256(code).

## Link verify
`POST /v1/link/verify`
```json
{"code":"123456","discordUserId":"123456789012345678"}
```
The operation is transactional. One Discord account and one Minecraft UUID can each be linked to at most one counterpart.

## Role sync
`POST /v1/discord/roles/sync`
```json
{"discordUserId":"123456789012345678","roleIds":["1571169862808506408","1572095943069671525"]}
```
This is a complete snapshot. An empty `roleIds` array removes all PSSMP role assignments for the linked Minecraft UUID. The Core plugin must map role IDs to known PSSMP roles and ignore unknown IDs.

## Account actions
`POST /v1/account/unlock-pin`
```json
{"minecraftUuid":"00000000-0000-0000-0000-000000000000","actorDiscordId":"123456789012345678","reason":"Ticket #12"}
```
`POST /v1/account/reset-password` uses the same shape. These queue durable actions for Core; API returns HTTP 202.

## Unlink
`POST /v1/account/unlink`
```json
{"minecraftUuid":"00000000-0000-0000-0000-000000000000"}
```
Deletes only the Discord link. It does not delete player profile, password, money, inventory, homes, or other Minecraft data.

## Error codes
- 400: malformed request
- 401: missing/invalid signature, stale timestamp, or replayed nonce
- 404: link code invalid/expired or account not linked
- 405: wrong HTTP method
- 500: internal/database failure
- 503: health check cannot reach database
