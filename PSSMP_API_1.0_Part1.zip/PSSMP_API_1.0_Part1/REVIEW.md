# Part 1 self-review

## Checks performed
- Reviewed all endpoint paths and HTTP methods.
- Checked Java source brace balance and imports.
- Confirmed every `/v1/*` handler authenticates before reading JSON.
- Confirmed request signatures use the exact raw body, timestamp, and nonce.
- Added a 64 KiB request-body ceiling.
- Added duplicate-role filtering before batch insert.
- Confirmed role sync is a transactional full snapshot.
- Confirmed account reset is queued for Core rather than deleting password hashes in the API.
- Confirmed unlink deletes only the Discord link, not Minecraft player data.
- Confirmed SQL uses prepared statements for user-controlled values.

## Not yet verified
- This environment has Java 21 and does not have Maven installed. The target server is Minecraft/Paper 26.3, which requires Java 25; therefore a real Java 25 Maven build could not be run here.
- MySQL integration tests were not run because no PSSMP database credentials/server were provided.
- Bot-to-API and Core-to-API live integration tests remain for later parts.
- TLS, reverse proxy, firewall, service supervision, production secrets, and Jumping host port/process support must be configured and tested on the actual host.
- The Core module must consume `pssmp_account_actions` safely and idempotently, and apply `pssmp_role_assignments` snapshots. Those consumers are not included in this API-only part.
- Add automated tests for HMAC vectors, replay rejection, link-code races, duplicate role snapshots, and DB failure recovery before production.

## Known design boundary
The API authenticates trusted service-to-service requests using one shared HMAC secret. It does not independently know Discord guild permissions. The Python bot must enforce the command's Discord role/owner authorization before calling administrative endpoints. The Minecraft Core must independently enforce in-game permissions.
