# PSSMP API 1.0 — Part 1

Independent Java API service for PSSMP. This is the first implementation part, not the complete server system.

## Runtime
- Java 25+
- MySQL 8+
- Maven 3.9+
- Intended Minecraft server target: Paper 26.3 (the API itself is server-independent).

## Included
- HTTP API process independent of the Minecraft plugin.
- MySQL connection pool.
- HMAC request authentication with timestamp + nonce + raw-body signature.
- Replay protection through a persisted nonce table.
- Health endpoint.
- Discord role synchronization endpoint.
- Account PIN unlock, password reset, and Discord unlink endpoints.
- Link-code creation and verification endpoints.
- SQL schema and environment-based configuration.

## Build
```bash
mvn clean package
```
Output: `target/pssmp-api-1.0.0.jar`

## Run
Copy `.env.example` values into your process environment, then:
```bash
java --add-modules jdk.httpserver -jar target/pssmp-api-1.0.0.jar
```

Do not expose the API publicly without TLS/reverse proxy, firewall restrictions, and a strong HMAC secret.
Do not commit secrets or real database credentials.

## HMAC contract (shared by Bot and Minecraft plugin)
Headers:
- `X-PSSMP-Timestamp`: Unix epoch seconds
- `X-PSSMP-Nonce`: unique random request nonce (at least 16 characters)
- `X-PSSMP-Signature`: lowercase hex HMAC-SHA256

Signed bytes are UTF-8:
`timestamp + "\\n" + nonce + "\\n" + exact_raw_HTTP_body`

The API rejects stale timestamps and reused nonces. Clients must sign the exact bytes they send.

## Endpoints
- `GET /health` — public process/database health.
- `POST /v1/link/create` — authenticated; creates a short-lived link code for a Minecraft UUID.
- `POST /v1/link/verify` — authenticated; verifies code and links Discord ID to Minecraft UUID.
- `POST /v1/discord/roles/sync` — authenticated; authoritative Discord role snapshot.
- `POST /v1/account/unlock-pin` — authenticated; removes PIN lock.
- `POST /v1/account/reset-password` — authenticated; removes login password so next join must register again.
- `POST /v1/account/unlink` — authenticated; removes only Discord-Minecraft link.

All endpoints use JSON. See `docs/API_CONTRACT.md`.

## Important implementation notes
- Role sync stores a complete snapshot, not additive role events. Send the full set of current PSSMP role IDs each time.
- Discord IDs are treated as strings to avoid 64-bit integer precision loss.
- Minecraft accounts are keyed by UUID, never by display name.
- Passwords are not stored by this API. The Minecraft Auth module owns password hashing and password records.
- `reset-password` writes an auth action request for Core to consume; it does not directly edit password hashes.
- This first part establishes the contract and persistence layer. It does not yet include the full Minecraft Core, gameplay modules, or Python Discord bot.
