CREATE TABLE IF NOT EXISTS pssmp_api_nonces (
  nonce VARCHAR(128) PRIMARY KEY,
  created_at TIMESTAMP NOT NULL,
  INDEX idx_nonce_created (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pssmp_link_codes (
  code_hash CHAR(64) PRIMARY KEY,
  minecraft_uuid CHAR(36) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  consumed_at TIMESTAMP NULL,
  created_at TIMESTAMP NOT NULL,
  INDEX idx_link_uuid (minecraft_uuid),
  INDEX idx_link_expiry (expires_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pssmp_discord_links (
  discord_user_id VARCHAR(20) PRIMARY KEY,
  minecraft_uuid CHAR(36) NOT NULL UNIQUE,
  linked_at TIMESTAMP NOT NULL,
  INDEX idx_discord_link_uuid (minecraft_uuid)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pssmp_role_assignments (
  minecraft_uuid CHAR(36) NOT NULL,
  discord_user_id VARCHAR(20) NOT NULL,
  discord_role_id VARCHAR(20) NOT NULL,
  synced_at TIMESTAMP NOT NULL,
  PRIMARY KEY (minecraft_uuid, discord_role_id),
  INDEX idx_role_discord (discord_user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pssmp_account_actions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  minecraft_uuid CHAR(36) NOT NULL,
  action ENUM('UNLOCK_PIN','RESET_PASSWORD') NOT NULL,
  actor_discord_id VARCHAR(20) NOT NULL,
  reason VARCHAR(500) NOT NULL DEFAULT '',
  status ENUM('PENDING','PROCESSING','COMPLETED','FAILED') NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP NOT NULL,
  processed_at TIMESTAMP NULL,
  INDEX idx_account_action_pending (status, id),
  INDEX idx_account_action_player (minecraft_uuid, id)
) ENGINE=InnoDB;

-- Run periodically to keep replay-protection storage bounded.
-- DELETE FROM pssmp_api_nonces WHERE created_at < NOW() - INTERVAL 2 DAY;
-- DELETE FROM pssmp_link_codes WHERE expires_at < NOW() - INTERVAL 2 DAY;
