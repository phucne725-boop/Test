# Auth flow

## First join
- Core checks `pssmp_auth_accounts` by Minecraft UUID.
- No row: `/dangky`, password twice, minimum 8 characters.
- Existing row: `/dangnhap`.
- PIN-locked row: `/unlock` first, then `/dangnhap`.

## Login barrier
- Darkness effect; movement and gameplay interaction blocked.
- Player is hidden from other players and cannot see other players.
- Login timeout defaults to 120 seconds.
- Only Auth commands are allowed before authentication.
- On successful login, normal visibility and movement are restored.

## Wrong credentials
- Five wrong attempts in a round cause a kick.
- Five consecutive kick rounds trigger a persisted one-hour block; login/PIN prompts check the relevant lock timestamp before proceeding.
- Password and PIN counters are stored separately in MySQL.
- Successful authentication resets the corresponding failure counters.

## PIN
- `/lock` asks for a six-digit PIN twice, saves a salted hash, marks PIN locked and kicks the player.
- On next join `/unlock` prompts for the PIN and clears the PIN lock after verification.
- `/dlock <password> <new PIN>` verifies account password and changes PIN.

## Password reset
- Trusted API integration can call `AuthRepository.resetPasswordByUuid(UUID)`.
- This deletes only the Auth row; profile, playtime, Discord link and gameplay data are not deleted.
- After reset, next join is treated as unregistered.
- The API/Bot endpoint and Admin/Helper permission gate must be connected and integration-tested before production.

## Security notes
- Passwords and PINs are never stored as plaintext.
- Password/PIN prompts are intercepted from chat and not broadcast.
- Password and PIN are never written to plugin logs by this module.
- `/dlock` takes the password as a command argument to preserve the specified syntax; command history/logging on some servers may expose command arguments. A future safer prompt variant is recommended before production.
