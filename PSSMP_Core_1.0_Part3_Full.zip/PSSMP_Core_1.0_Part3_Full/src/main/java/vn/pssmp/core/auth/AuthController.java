package vn.pssmp.core.auth;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public final class AuthController implements Listener {
    private enum Prompt { REGISTER_ONE, REGISTER_TWO, LOGIN, CHANGE_OLD, CHANGE_NEW, CHANGE_CONFIRM, SET_PIN, CONFIRM_PIN, PIN_LOGIN }
    private final JavaPlugin plugin;
    private final AuthRepository repository;
    private final Map<UUID, AuthState> states = new ConcurrentHashMap<>();
    private final Map<UUID, Prompt> prompts = new ConcurrentHashMap<>();
    private final Map<UUID, String> firstEntry = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> attemptsThisRound = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> pinAttemptsThisRound = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> timeoutTasks = new ConcurrentHashMap<>();
    private final Set<UUID> verifiedPasswordForPinChange = ConcurrentHashMap.newKeySet();

    public AuthController(JavaPlugin plugin, AuthRepository repository) {
        this.plugin = plugin; this.repository = repository;
    }

    public void start() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
        for (Player player : Bukkit.getOnlinePlayers()) beginJoin(player);
    }

    public AuthState state(UUID uuid) { return states.getOrDefault(uuid, AuthState.NEEDS_LOGIN); }
    public boolean isAuthenticated(UUID uuid) { return state(uuid) == AuthState.AUTHENTICATED; }

    public void beginJoin(Player player) {
        UUID id = player.getUniqueId();
        states.put(id, AuthState.NEEDS_LOGIN);
        applyLoginBarrier(player);
        repository.find(id).whenComplete((record, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            if (error != null) {
                player.kickPlayer(ChatColor.RED + "Không thể kiểm tra tài khoản lúc này. Hãy thử vào lại sau.");
                return;
            }
            if (record.isEmpty()) {
                states.put(id, AuthState.NEEDS_REGISTER);
                player.sendMessage(ChatColor.AQUA + "Chưa có tài khoản. Dùng /dangky để đăng ký.");
            } else if (record.get().pinLocked()) {
                if (record.get().pinLockedUntil() > System.currentTimeMillis() / 1000L) {
                    player.kickPlayer(ChatColor.RED + "PIN đang bị tạm khóa do nhập sai quá nhiều lần.");
                    return;
                }
                states.put(id, AuthState.NEEDS_PIN_UNLOCK);
                player.sendMessage(ChatColor.YELLOW + "Tài khoản đang khóa PIN. Dùng /unlock để mở khóa.");
            } else {
                if (record.get().passwordLockedUntil() > System.currentTimeMillis() / 1000L) {
                    player.kickPlayer(ChatColor.RED + "Tài khoản đang bị khóa đăng nhập trong 1 giờ do nhập sai quá nhiều lần.");
                    return;
                }
                states.put(id, AuthState.NEEDS_LOGIN);
                player.sendMessage(ChatColor.AQUA + "Vui lòng đăng nhập bằng /dangnhap.");
            }
            startTimeout(player);
        }));
    }

    private void startTimeout(Player player) {
        int seconds = Math.max(30, plugin.getConfig().getInt("auth.login-timeout-seconds", 120));
        int task = Bukkit.getScheduler().scheduleSyncDelayedTask(plugin, () -> {
            if (player.isOnline() && !isAuthenticated(player.getUniqueId()))
                player.kickPlayer(ChatColor.RED + "Bạn đã hết thời gian đăng nhập.");
        }, seconds * 20L);
        timeoutTasks.put(player.getUniqueId(), task);
    }

    private void applyLoginBarrier(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
        player.setWalkSpeed(0f);
        player.setFlySpeed(0f);
        for (Player other : Bukkit.getOnlinePlayers()) {
            if (!other.equals(player)) {
                player.hidePlayer(plugin, other);
                other.hidePlayer(plugin, player);
            }
        }
    }

    private void releaseLoginBarrier(Player player) {
        player.removePotionEffect(PotionEffectType.BLINDNESS);
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.1f);
        for (Player other : Bukkit.getOnlinePlayers()) {
            if (!other.equals(player)) {
                player.showPlayer(plugin, other);
                other.showPlayer(plugin, player);
            }
        }
        Integer task = timeoutTasks.remove(player.getUniqueId());
        if (task != null) Bukkit.getScheduler().cancelTask(task);
        states.put(player.getUniqueId(), AuthState.AUTHENTICATED);
        prompts.remove(player.getUniqueId());
        firstEntry.remove(player.getUniqueId());
        player.sendMessage(ChatColor.GREEN + "Đăng nhập thành công!");
    }

    public void prompt(Player player, Prompt prompt, String message) {
        prompts.put(player.getUniqueId(), prompt);
        player.sendMessage(ChatColor.YELLOW + message);
    }

    public boolean isPrompting(UUID uuid) { return prompts.containsKey(uuid); }

    @EventHandler public void onJoin(PlayerJoinEvent event) { beginJoin(event.getPlayer()); }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        states.remove(id); prompts.remove(id); firstEntry.remove(id);
        attemptsThisRound.remove(id); pinAttemptsThisRound.remove(id);
        verifiedPasswordForPinChange.remove(id);
        Integer task = timeoutTasks.remove(id);
        if (task != null) Bukkit.getScheduler().cancelTask(task);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent event) {
        if (!isAuthenticated(event.getPlayer().getUniqueId()) && event.getTo() != null) {
            Location from = event.getFrom(), to = event.getTo();
            if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ())
                event.setTo(from);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST) public void onInteract(PlayerInteractEvent e) { block(e); }
    @EventHandler(priority = EventPriority.HIGHEST) public void onInteractEntity(PlayerInteractEntityEvent e) { block(e); }
    @EventHandler(priority = EventPriority.HIGHEST) public void onBreak(BlockBreakEvent e) { if (!isAuthenticated(e.getPlayer().getUniqueId())) e.setCancelled(true); }
    @EventHandler(priority = EventPriority.HIGHEST) public void onPlace(BlockPlaceEvent e) { if (!isAuthenticated(e.getPlayer().getUniqueId())) e.setCancelled(true); }
    @EventHandler(priority = EventPriority.HIGHEST) public void onInventory(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && !isAuthenticated(p.getUniqueId())) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST) public void onDrop(PlayerDropItemEvent e) {
        if (!isAuthenticated(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST) public void onPickup(PlayerAttemptPickupItemEvent e) {
        if (!isAuthenticated(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST) public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && !isAuthenticated(p.getUniqueId())) e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST) public void onCommand(PlayerCommandPreprocessEvent e) {
        if (isAuthenticated(e.getPlayer().getUniqueId())) return;
        String command = e.getMessage().toLowerCase().split(" ")[0];
        if (!Set.of("/dangky", "/dangnhap", "/doimatkhau", "/lock", "/unlock", "/dlock").contains(command))
            e.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST) public void onChat(AsyncPlayerChatEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Prompt prompt = prompts.get(id);
        if (prompt == null) {
            if (!isAuthenticated(id)) e.setCancelled(true);
            return;
        }
        e.setCancelled(true);
        String input = e.getMessage();
        Bukkit.getScheduler().runTask(plugin, () -> handlePrompt(e.getPlayer(), prompt, input));
    }

    private void handlePrompt(Player player, Prompt prompt, String input) {
        UUID id = player.getUniqueId();
        switch (prompt) {
            case REGISTER_ONE -> {
                if (!validPassword(input)) { player.sendMessage(ChatColor.RED + "Mật khẩu cần ít nhất 8 ký tự."); return; }
                firstEntry.put(id, input);
                prompt(player, Prompt.REGISTER_TWO, "Nhập lại mật khẩu để xác nhận:");
            }
            case REGISTER_TWO -> {
                String first = firstEntry.get(id);
                if (first == null || !first.equals(input)) {
                    firstEntry.remove(id); prompt(player, Prompt.REGISTER_ONE, "Mật khẩu không trùng. Nhập mật khẩu mới:");
                    return;
                }
                repository.register(id, input.toCharArray()).whenComplete((ok, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    if (err != null || !Boolean.TRUE.equals(ok)) player.sendMessage(ChatColor.RED + "Đăng ký thất bại. Hãy thử lại.");
                    else releaseLoginBarrier(player);
                }));
            }
            case LOGIN -> repository.verifyPassword(id, input.toCharArray()).whenComplete((ok, err) ->
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (err != null) { player.sendMessage(ChatColor.RED + "Không thể kiểm tra mật khẩu lúc này."); return; }
                        if (Boolean.TRUE.equals(ok)) {
                            attemptsThisRound.remove(id);
                            repository.clearFailures(id, false);
                            releaseLoginBarrier(player);
                        } else handleFailedAttempt(player, false);
                    }));
            case CHANGE_OLD -> repository.verifyPassword(id, input.toCharArray()).whenComplete((ok, err) ->
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (Boolean.TRUE.equals(ok)) prompt(player, Prompt.CHANGE_NEW, "Nhập mật khẩu mới (ít nhất 8 ký tự):");
                        else prompt(player, Prompt.CHANGE_OLD, "Mật khẩu cũ không đúng. Nhập lại:");
                    }));
            case CHANGE_NEW -> {
                if (!validPassword(input)) { player.sendMessage(ChatColor.RED + "Mật khẩu cần ít nhất 8 ký tự."); return; }
                firstEntry.put(id, input);
                prompt(player, Prompt.CHANGE_CONFIRM, "Nhập lại mật khẩu mới:");
            }
            case CHANGE_CONFIRM -> {
                String first = firstEntry.get(id);
                if (first == null || !first.equals(input)) {
                    firstEntry.remove(id); prompt(player, Prompt.CHANGE_NEW, "Không trùng khớp. Nhập mật khẩu mới:");
                    return;
                }
                repository.changePassword(id, input.toCharArray()).whenComplete((ok, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    firstEntry.remove(id); prompts.remove(id);
                    player.sendMessage(err == null && Boolean.TRUE.equals(ok)
                            ? ChatColor.GREEN + "Đã đổi mật khẩu." : ChatColor.RED + "Đổi mật khẩu thất bại.");
                }));
            }
            case SET_PIN -> {
                if (!input.matches("\\d{6}")) { player.sendMessage(ChatColor.RED + "PIN phải gồm đúng 6 chữ số."); return; }
                firstEntry.put(id, input);
                prompt(player, Prompt.CONFIRM_PIN, "Nhập lại PIN để xác nhận:");
            }
            case CONFIRM_PIN -> {
                String first = firstEntry.get(id);
                if (first == null || !first.equals(input)) {
                    firstEntry.remove(id); prompt(player, Prompt.SET_PIN, "PIN không trùng. Nhập PIN mới:");
                    return;
                }
                repository.setPin(id, input.toCharArray(), true).whenComplete((ok, err) -> Bukkit.getScheduler().runTask(plugin, () -> {
                    firstEntry.remove(id); prompts.remove(id);
                    if (err != null || !Boolean.TRUE.equals(ok)) {
                        player.sendMessage(ChatColor.RED + "Không thể lưu PIN. Tài khoản chưa bị khóa.");
                    } else {
                        player.kickPlayer(ChatColor.YELLOW + "Bạn đã khóa tài khoản bằng PIN. Hãy đăng nhập lại và dùng /unlock.");
                    }
                }));
            }
            case PIN_LOGIN -> repository.verifyPin(id, input.toCharArray()).whenComplete((ok, err) ->
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        if (err != null) { player.sendMessage(ChatColor.RED + "Không thể kiểm tra PIN lúc này."); return; }
                        if (Boolean.TRUE.equals(ok)) {
                            pinAttemptsThisRound.remove(id);
                            repository.clearFailures(id, true).thenCompose(v -> repository.unlockPin(id))
                                    .whenComplete((v, failure) -> Bukkit.getScheduler().runTask(plugin, () -> {
                                        if (failure != null) player.sendMessage(ChatColor.RED + "Không thể mở khóa lúc này.");
                                        else {
                                            states.put(id, AuthState.NEEDS_LOGIN);
                                            prompts.remove(id);
                                            player.sendMessage(ChatColor.GREEN + "Đã mở khóa PIN. Tiếp tục /dangnhap.");
                                        }
                                    }));
                        } else handleFailedAttempt(player, true);
                    }));
        }
    }

    private void handleFailedAttempt(Player player, boolean pin) {
        UUID id = player.getUniqueId();
        Map<UUID, Integer> counter = pin ? pinAttemptsThisRound : attemptsThisRound;
        int count = counter.merge(id, 1, Integer::sum);
        repository.recordFailure(id, pin);
        if (count >= 5) {
            counter.put(id, 0);
            player.kickPlayer(ChatColor.RED + "Bạn đã nhập sai 5 lần. Hãy thử đăng nhập lại.");
        } else {
            prompt(player, pin ? Prompt.PIN_LOGIN : Prompt.LOGIN,
                    "Sai thông tin. Còn " + (5 - count) + " lần thử.");
        }
    }

    private static boolean validPassword(String input) { return input != null && input.length() >= 8 && input.length() <= 128; }

    private void block(PlayerEvent e) {
        if (!isAuthenticated(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    public void beginPasswordChange(Player player) { prompt(player, Prompt.CHANGE_OLD, "Nhập mật khẩu hiện tại:"); }
    public void beginRegister(Player player) { prompt(player, Prompt.REGISTER_ONE, "Nhập mật khẩu mới (ít nhất 8 ký tự):"); }
    public void beginLogin(Player player) {
        repository.find(player.getUniqueId()).whenComplete((record, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null || record.isEmpty()) {
                player.sendMessage(ChatColor.RED + "Không thể kiểm tra tài khoản lúc này.");
                return;
            }
            if (record.get().passwordLockedUntil() > System.currentTimeMillis() / 1000L) {
                player.kickPlayer(ChatColor.RED + "Tài khoản đang bị khóa đăng nhập trong 1 giờ do nhập sai quá nhiều lần.");
                return;
            }
            prompt(player, Prompt.LOGIN, "Nhập mật khẩu:");
        }));
    }
    public void beginLock(Player player) { prompt(player, Prompt.SET_PIN, "Nhập PIN gồm 6 chữ số để khóa tài khoản:"); }
    public void beginUnlock(Player player) {
        repository.find(player.getUniqueId()).whenComplete((record, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null || record.isEmpty() || !record.get().pinLocked()) {
                player.sendMessage(ChatColor.RED + "Tài khoản không ở trạng thái khóa PIN.");
                return;
            }
            prompt(player, Prompt.PIN_LOGIN, "Nhập PIN 6 chữ số:");
        }));
    }

    public void changePinWithPassword(Player player, String password, String newPin) {
        if (!newPin.matches("\\d{6}")) { player.sendMessage(ChatColor.RED + "PIN mới phải gồm 6 chữ số."); return; }
        repository.verifyPassword(player.getUniqueId(), password.toCharArray()).whenComplete((ok, err) ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (err != null || !Boolean.TRUE.equals(ok)) {
                        player.sendMessage(ChatColor.RED + "Mật khẩu không đúng.");
                        return;
                    }
                    repository.setPin(player.getUniqueId(), newPin.toCharArray(), false).whenComplete((saved, failure) ->
                            Bukkit.getScheduler().runTask(plugin, () -> player.sendMessage(failure == null
                                    ? ChatColor.GREEN + "Đã đổi PIN." : ChatColor.RED + "Không thể đổi PIN.")));
                }));
    }
}
