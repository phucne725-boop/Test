package vn.pssmp.core.auth;

public enum AuthState {
    NEEDS_REGISTER,
    NEEDS_LOGIN,
    NEEDS_PIN_UNLOCK,
    AUTHENTICATED
}
