package vn.pssmp.core.auth;

import vn.pssmp.core.db.Database;
import vn.pssmp.core.auth.PasswordHasher.Hash;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

public final class AuthRepository {
    private final Database database;
    private final ExecutorService executor;
    private final PasswordHasher hasher = new PasswordHasher();

    public AuthRepository(Database database, ExecutorService executor) {
        this.database = database;
        this.executor = executor;
    }

    public CompletableFuture<Optional<AuthRecord>> find(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            String sql = "SELECT password_hash,password_salt,pin_hash,pin_salt,pin_locked," +
                    "failed_password_attempts,password_kick_rounds,password_locked_until," +
                    "failed_pin_attempts,pin_kick_rounds,pin_locked_until " +
                    "FROM pssmp_auth_accounts WHERE minecraft_uuid=?";
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, uuid.toString());
                try (ResultSet r = p.executeQuery()) {
                    if (!r.next()) return Optional.empty();
                    return Optional.of(new AuthRecord(true, r.getString("password_hash"), r.getString("password_salt"),
                            r.getString("pin_hash"), r.getString("pin_salt"), r.getBoolean("pin_locked"),
                            r.getInt("failed_password_attempts"), r.getInt("password_kick_rounds"),
                            r.getLong("password_locked_until"), r.getInt("failed_pin_attempts"),
                            r.getInt("pin_kick_rounds"), r.getLong("pin_locked_until")));
                }
            } catch (SQLException e) { throw new IllegalStateException("Could not read auth record", e); }
        }, executor);
    }

    public CompletableFuture<Boolean> register(UUID uuid, char[] password) {
        return CompletableFuture.supplyAsync(() -> {
            Hash hash = hasher.hash(password);
            String sql = "INSERT INTO pssmp_auth_accounts(minecraft_uuid,password_hash,password_salt) VALUES(?,?,?)";
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, uuid.toString()); p.setString(2, hash.encoded()); p.setString(3, hash.salt());
                return p.executeUpdate() == 1;
            } catch (SQLException e) {
                if (isDuplicate(e)) return false;
                throw new IllegalStateException("Could not register account", e);
            } finally { java.util.Arrays.fill(password, '\0'); }
        }, executor);
    }

    public CompletableFuture<Boolean> verifyPassword(UUID uuid, char[] password) {
        return find(uuid).thenApplyAsync(record -> {
            try {
                return record.isPresent() && hasher.verify(password, record.get().passwordHash(), record.get().passwordSalt());
            } finally { java.util.Arrays.fill(password, '\0'); }
        }, executor);
    }

    public CompletableFuture<Boolean> changePassword(UUID uuid, char[] newPassword) {
        return CompletableFuture.supplyAsync(() -> {
            Hash hash = hasher.hash(newPassword);
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(
                    "UPDATE pssmp_auth_accounts SET password_hash=?,password_salt=?,failed_password_attempts=0,password_kick_rounds=0,password_locked_until=0 WHERE minecraft_uuid=?")) {
                p.setString(1, hash.encoded()); p.setString(2, hash.salt()); p.setString(3, uuid.toString());
                return p.executeUpdate() == 1;
            } catch (SQLException e) { throw new IllegalStateException("Could not change password", e); }
            finally { java.util.Arrays.fill(newPassword, '\0'); }
        }, executor);
    }

    public CompletableFuture<Boolean> setPin(UUID uuid, char[] pin, boolean lockNow) {
        return CompletableFuture.supplyAsync(() -> {
            Hash hash = hasher.hash(pin);
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(
                    "UPDATE pssmp_auth_accounts SET pin_hash=?,pin_salt=?,pin_locked=?,failed_pin_attempts=0,pin_kick_rounds=0,pin_locked_until=0 WHERE minecraft_uuid=?")) {
                p.setString(1, hash.encoded()); p.setString(2, hash.salt()); p.setBoolean(3, lockNow);
                p.setString(4, uuid.toString()); return p.executeUpdate() == 1;
            } catch (SQLException e) { throw new IllegalStateException("Could not save PIN", e); }
            finally { java.util.Arrays.fill(pin, '\0'); }
        }, executor);
    }

    public CompletableFuture<Boolean> verifyPin(UUID uuid, char[] pin) {
        return find(uuid).thenApplyAsync(record -> {
            try {
                return record.isPresent() && record.get().pinHash() != null &&
                        hasher.verify(pin, record.get().pinHash(), record.get().pinSalt());
            } finally { java.util.Arrays.fill(pin, '\0'); }
        }, executor);
    }

    public CompletableFuture<Void> unlockPin(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(
                    "UPDATE pssmp_auth_accounts SET pin_locked=FALSE,failed_pin_attempts=0,pin_kick_rounds=0,pin_locked_until=0 WHERE minecraft_uuid=?")) {
                p.setString(1, uuid.toString()); p.executeUpdate();
            } catch (SQLException e) { throw new IllegalStateException("Could not unlock PIN", e); }
        }, executor);
    }

    public CompletableFuture<Boolean> recordFailure(UUID uuid, boolean pinFailure) {
        return CompletableFuture.supplyAsync(() -> {
            String attempts = pinFailure ? "failed_pin_attempts" : "failed_password_attempts";
            String rounds = pinFailure ? "pin_kick_rounds" : "password_kick_rounds";
            String lockedUntil = pinFailure ? "pin_locked_until" : "password_locked_until";
            // MySQL evaluates single-table UPDATE assignments left-to-right:
            // calculate the lock using the pre-increment counters first.
            String sql = "UPDATE pssmp_auth_accounts SET " +
                    lockedUntil + "=CASE WHEN " + attempts + ">=4 AND " + rounds + ">=4 " +
                    "THEN UNIX_TIMESTAMP()+3600 ELSE " + lockedUntil + " END," +
                    rounds + "=CASE WHEN " + attempts + ">=4 THEN " + rounds + "+1 ELSE " + rounds + " END," +
                    attempts + "=CASE WHEN " + attempts + ">=4 THEN 0 ELSE " + attempts + "+1 END " +
                    "WHERE minecraft_uuid=?";
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, uuid.toString());
                return p.executeUpdate() == 1;
            } catch (SQLException e) {
                throw new IllegalStateException("Could not record failed attempt", e);
            }
        }, executor);
    }

    public CompletableFuture<Void> clearFailures(UUID uuid, boolean pinFailure) {
        return CompletableFuture.runAsync(() -> {
            String sql = pinFailure
                    ? "UPDATE pssmp_auth_accounts SET failed_pin_attempts=0,pin_kick_rounds=0,pin_locked_until=0 WHERE minecraft_uuid=?"
                    : "UPDATE pssmp_auth_accounts SET failed_password_attempts=0,password_kick_rounds=0,password_locked_until=0 WHERE minecraft_uuid=?";
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, uuid.toString()); p.executeUpdate();
            } catch (SQLException e) { throw new IllegalStateException("Could not clear failed attempts", e); }
        }, executor);
    }

    /** Called by the trusted API after Discord Admin/Helper executes /kptk. */
    public CompletableFuture<Void> resetPasswordByUuid(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection c = database.connection(); PreparedStatement p = c.prepareStatement(
                    "DELETE FROM pssmp_auth_accounts WHERE minecraft_uuid=?")) {
                p.setString(1, uuid.toString()); p.executeUpdate();
            } catch (SQLException e) { throw new IllegalStateException("Could not reset password", e); }
        }, executor);
    }

    private static boolean isDuplicate(SQLException e) { return e.getErrorCode() == 1062; }
}
