package vn.pssmp.core.auth;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import vn.pssmp.core.db.Database;

public final class AuthModule {
    private final AuthRepository repository;
    private final AuthController controller;

    public AuthModule(JavaPlugin plugin, Database database, java.util.concurrent.ExecutorService executor) {
        repository = new AuthRepository(database, executor);
        controller = new AuthController(plugin, repository);
        AuthCommand command = new AuthCommand(controller);
        for (String name : new String[]{"dangky", "dangnhap", "doimatkhau", "lock", "unlock", "dlock"}) {
            if (plugin.getCommand(name) != null) plugin.getCommand(name).setExecutor(command);
        }
    }

    public void start() { controller.start(); }
    public AuthRepository repository() { return repository; }
    public AuthController controller() { return controller; }
}
