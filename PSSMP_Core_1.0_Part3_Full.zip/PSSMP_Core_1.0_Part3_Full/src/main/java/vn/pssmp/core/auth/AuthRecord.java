package vn.pssmp.core.auth;

public record AuthRecord(
        boolean registered,
        String passwordHash,
        String passwordSalt,
        String pinHash,
        String pinSalt,
        boolean pinLocked,
        int failedPasswordAttempts,
        int passwordKickRounds,
        long passwordLockedUntil,
        int failedPinAttempts,
        int pinKickRounds,
        long pinLockedUntil
) {}
