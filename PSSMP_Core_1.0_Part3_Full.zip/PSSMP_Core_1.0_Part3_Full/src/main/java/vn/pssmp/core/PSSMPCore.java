package vn.pssmp.core;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import vn.pssmp.core.command.StatsCommand;\nimport vn.pssmp.core.auth.AuthModule;
import vn.pssmp.core.db.Database;
import vn.pssmp.core.permission.PermissionManager;
import vn.pssmp.core.player.PlaytimeTracker;
import vn.pssmp.core.player.ProfileRepository;
import vn.pssmp.core.role.RoleSyncService;
import vn.pssmp.core.service.PSSMPServices;

import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class PSSMPCore extends JavaPlugin {
    private Database database;
    private ExecutorService databaseExecutor;
    private ProfileRepository profiles;
    private PermissionManager permissions;
    private PlaytimeTracker playtime;
    private RoleSyncService roleSync;\n    private AuthModule auth;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            validateConfiguration();
            databaseExecutor = Executors.newFixedThreadPool(4, r -> {
                Thread t = new Thread(r, "PSSMP-DB-Worker");
                t.setDaemon(true);
                return t;
            });
            database = new Database(this);
            database.open();
            profiles = new ProfileRepository(this, database, databaseExecutor);
            permissions = new PermissionManager();
            roleSync = new RoleSyncService(this, database, permissions, databaseExecutor);
            playtime = new PlaytimeTracker(this, profiles);\n            auth = new AuthModule(this, database, databaseExecutor);

            Bukkit.getServicesManager().register(PSSMPServices.class,
                    new PSSMPServices(database, profiles, permissions), this, ServicePriority.Normal);
            Objects.requireNonNull(getCommand("stats"), "stats command missing")
                    .setExecutor(new StatsCommand(this, profiles, permissions));
            Bukkit.getPluginManager().registerEvents(playtime, this);

            profiles.loadOnlinePlayers();
            playtime.start();
            roleSync.start();\n            auth.start();
            getLogger().info("PSSMP-Core 1.0 enabled.");
        } catch (Exception ex) {
            getLogger().severe("Core startup failed safely: " + ex.getMessage());
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        if (playtime != null) playtime.flushAllSynchronously();
        if (roleSync != null) roleSync.stop();
        if (databaseExecutor != null) {
            databaseExecutor.shutdown();
            try {
                if (!databaseExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    databaseExecutor.shutdownNow();
                    databaseExecutor.awaitTermination(2, TimeUnit.SECONDS);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                databaseExecutor.shutdownNow();
            }
        }
        if (database != null) database.close();
    }

    private void validateConfiguration() {
        String url = getConfig().getString("database.jdbc-url", "");
        String user = getConfig().getString("database.username", "");
        String password = getConfig().getString("database.password", "");
        if (url.isBlank() || user.isBlank() || password.isBlank() || password.equals("CHANGE_ME"))
            throw new IllegalStateException("Configure database credentials in plugins/PSSMP-Core/config.yml.");
        if (getConfig().getInt("roles.sync-interval-seconds", 30) < 5)
            throw new IllegalStateException("Role sync interval must be at least 5 seconds.");
    }

    public String message(String key) {
        return ChatColor.translateAlternateColorCodes('&',
                getConfig().getString("messages." + key, "&cMissing message: " + key));
    }
}
