# PHUT CITY 1.0 — development source

This is a newly created source project, not based on the old test JAR. It is an initial development foundation, **not yet the complete PHUT CITY 1.0 feature set**.

## Build

Requires JDK 25 and Gradle. The GitHub Actions workflow builds on pushes to `main` and manual workflow dispatch. It uploads `PHUT-CITY-1.0.jar` as an artifact.

The Paper API coordinate is configured in `gradle.properties` as `paperVersion=26.3-R0.1-SNAPSHOT`. Verify/change this to the exact published Paper API version for the server build before compiling; if Paper does not publish this coordinate, the dependency resolution step will fail.

## Implemented in this initial foundation

- Plugin bootstrap and configuration resources.
- UUID-keyed YAML player data persistence.
- Password/PIN salted SHA-256 hash helper.
- Basic registration/login state, PIN lock/unlock commands.
- Bank-balance field and online-player bank transfer command.
- Scoreboard with name, job, corporation and XP (no personal balance).
- Local chat radius configuration (default 5 blocks).
- `/admintool` permission gate placeholder and GitHub Actions Java 25 build workflow.

## Not implemented yet

The full authentication world/freeze enforcement, robust password KDF, account anti-impersonation, complete LOCK visibility/inventory restrictions, banknotes and ATM GUI, transaction history/purpose/XP rules, full phone apps and private messages/calls, companies and payroll, NPC editor/shops, land regions and `/edit`, hospital/fainting/inventory rules, police workflow, leaderboards, Discord bot API, temperature/thirst integration, Bedrock/Geyser compatibility testing, and full admin GUI are still outstanding. Do not deploy this development build as a finished city server plugin.

## Scope exclusions

No vehicles, taxi job, bus/farmer jobs, tax, GPS/map app, gangs, robbery, money laundering, or individual wealth leaderboard are included in the 1.0 plan.
