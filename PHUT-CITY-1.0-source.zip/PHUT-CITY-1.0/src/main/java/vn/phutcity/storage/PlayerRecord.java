package vn.phutcity.storage;

import java.util.UUID;

public final class PlayerRecord {
    private final UUID uuid;
    private String passwordHash = "";
    private String pinHash = "";
    private boolean locked;
    private boolean authenticated;
    private long bankBalance;
    private long cashBalance;
    private long xp;
    private String job = "Không có";
    private String corporation = "Không có";

    public PlayerRecord(UUID uuid) { this.uuid = uuid; }
    public UUID uuid() { return uuid; }
    public String passwordHash() { return passwordHash; }
    public void passwordHash(String value) { passwordHash = value; }
    public String pinHash() { return pinHash; }
    public void pinHash(String value) { pinHash = value; }
    public boolean locked() { return locked; }
    public void locked(boolean value) { locked = value; }
    public boolean authenticated() { return authenticated; }
    public void authenticated(boolean value) { authenticated = value; }
    public long bankBalance() { return bankBalance; }
    public void bankBalance(long value) { bankBalance = Math.max(0, value); }
    public long cashBalance() { return cashBalance; }
    public void cashBalance(long value) { cashBalance = Math.max(0, value); }
    public long xp() { return xp; }
    public void xp(long value) { xp = Math.max(0, value); }
    public String job() { return job; }
    public void job(String value) { job = value; }
    public String corporation() { return corporation; }
    public void corporation(String value) { corporation = value; }
}
