package vn.phutcity.storage;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import vn.phutcity.PhutCityPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PlayerDataStore {
    private final PhutCityPlugin plugin;
    private final Map<UUID, PlayerRecord> records = new ConcurrentHashMap<>();
    private final File file;

    public PlayerDataStore(PhutCityPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }
    public PlayerRecord get(UUID uuid) { return records.computeIfAbsent(uuid, PlayerRecord::new); }
    public Map<UUID, PlayerRecord> all() { return Map.copyOf(records); }

    public synchronized void load() {
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yaml.getConfigurationSection("players");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                ConfigurationSection s = root.getConfigurationSection(key);
                if (s == null) continue;
                PlayerRecord r = new PlayerRecord(id);
                r.passwordHash(s.getString("password", ""));
                r.pinHash(s.getString("pin", ""));
                r.locked(s.getBoolean("locked"));
                r.bankBalance(s.getLong("bank"));
                r.cashBalance(s.getLong("cash"));
                r.xp(s.getLong("xp"));
                r.job(s.getString("job", "Không có"));
                r.corporation(s.getString("corporation", "Không có"));
                records.put(id, r);
            } catch (IllegalArgumentException ex) { plugin.getLogger().warning("Invalid player UUID in players.yml: " + key); }
        }
    }

    public synchronized void saveAll() {
        if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) return;
        YamlConfiguration yaml = new YamlConfiguration();
        for (PlayerRecord r : records.values()) {
            String path = "players." + r.uuid();
            yaml.set(path + ".password", r.passwordHash());
            yaml.set(path + ".pin", r.pinHash());
            yaml.set(path + ".locked", r.locked());
            yaml.set(path + ".bank", r.bankBalance());
            yaml.set(path + ".cash", r.cashBalance());
            yaml.set(path + ".xp", r.xp());
            yaml.set(path + ".job", r.job());
            yaml.set(path + ".corporation", r.corporation());
        }
        try { yaml.save(file); } catch (IOException ex) { plugin.getLogger().severe("Could not save players.yml: " + ex.getMessage()); }
    }
}
