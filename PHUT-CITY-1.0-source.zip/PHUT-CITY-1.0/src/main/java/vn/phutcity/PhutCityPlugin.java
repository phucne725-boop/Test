package vn.phutcity;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import vn.phutcity.account.AccountService;
import vn.phutcity.economy.EconomyService;
import vn.phutcity.phone.LocalChatListener;
import vn.phutcity.scoreboard.ScoreboardService;
import vn.phutcity.storage.PlayerDataStore;
import vn.phutcity.util.CityCommand;

public final class PhutCityPlugin extends JavaPlugin {
    private PlayerDataStore dataStore;
    private AccountService accounts;
    private EconomyService economy;
    private ScoreboardService scoreboard;

    @Override public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);
        dataStore = new PlayerDataStore(this);
        accounts = new AccountService(this, dataStore);
        economy = new EconomyService(this, dataStore);
        scoreboard = new ScoreboardService(this, dataStore);

        Bukkit.getPluginManager().registerEvents(new LocalChatListener(this, accounts), this);
        Bukkit.getPluginManager().registerEvents(accounts, this);
        Bukkit.getPluginManager().registerEvents(scoreboard, this);

        register("dangky", new CityCommand(accounts, "register"));
        register("dangnhap", new CityCommand(accounts, "login"));
        register("lock", new CityCommand(accounts, "lock"));
        register("unlock", new CityCommand(accounts, "unlock"));
        register("money", new CityCommand(economy, "money"));
        register("pay", new CityCommand(economy, "pay"));
        register("checkxp", new CityCommand(scoreboard, "checkxp"));
        register("admintool", new CityCommand(this, "admintool"));

        Bukkit.getScheduler().runTaskTimerAsynchronously(this, dataStore::saveAll, 20L * 60, 20L * 60);
        getLogger().info("PHUT CITY foundation enabled. This is a development build.");
    }

    private void register(String name, CityCommand command) {
        if (getCommand(name) != null) getCommand(name).setExecutor(command);
    }

    @Override public void onDisable() { if (dataStore != null) dataStore.saveAll(); }
    public PlayerDataStore data() { return dataStore; }
    public AccountService accounts() { return accounts; }
    public EconomyService economy() { return economy; }
}
