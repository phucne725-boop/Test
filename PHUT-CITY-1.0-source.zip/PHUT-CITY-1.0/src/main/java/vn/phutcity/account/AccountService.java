package vn.phutcity.account;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import vn.phutcity.PhutCityPlugin;
import vn.phutcity.storage.PlayerDataStore;
import vn.phutcity.storage.PlayerRecord;
import vn.phutcity.util.PasswordUtil;

public final class AccountService implements Listener {
    private final PhutCityPlugin plugin; private final PlayerDataStore data;
    public AccountService(PhutCityPlugin plugin, PlayerDataStore data) { this.plugin = plugin; this.data = data; }
    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer(); PlayerRecord r = data.get(p.getUniqueId()); r.authenticated(false);
        p.sendMessage(ChatColor.AQUA + "PHUT CITY: " + (r.passwordHash().isBlank() ? "Dung /dangky <mat_khau> <nhap_lai>" : "Dung /dangnhap <mat_khau>"));
        if (r.locked()) p.sendMessage(ChatColor.RED + "Tai khoan dang LOCK. Dung /unlock <PIN>.");
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) { data.get(event.getPlayer().getUniqueId()).authenticated(false); }
    public boolean register(Player p, String password, String repeat) {
        PlayerRecord r = data.get(p.getUniqueId());
        if (!r.passwordHash().isBlank() || password.length() < 6 || !password.equals(repeat)) return false;
        r.passwordHash(PasswordUtil.hash(password)); r.authenticated(true); data.saveAll(); return true;
    }
    public boolean login(Player p, String password) {
        PlayerRecord r = data.get(p.getUniqueId());
        if (r.passwordHash().isBlank() || !PasswordUtil.verify(password, r.passwordHash())) return false;
        r.authenticated(true); return true;
    }
    public boolean lock(Player p, String pin) {
        if (!pin.matches("\\d{4,8}")) return false;
        PlayerRecord r = data.get(p.getUniqueId()); r.pinHash(PasswordUtil.hash(pin)); r.locked(true); data.saveAll(); return true;
    }
    public boolean unlock(Player p, String pin) {
        PlayerRecord r = data.get(p.getUniqueId());
        if (!r.locked() || !PasswordUtil.verify(pin, r.pinHash())) return false;
        r.locked(false); data.saveAll(); return true;
    }
    public boolean canPlay(Player p) { PlayerRecord r = data.get(p.getUniqueId()); return r.authenticated() && !r.locked(); }
    public PlayerRecord record(Player p) { return data.get(p.getUniqueId()); }
}
