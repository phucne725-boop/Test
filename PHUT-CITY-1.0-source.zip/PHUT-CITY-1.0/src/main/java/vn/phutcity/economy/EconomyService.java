package vn.phutcity.economy;

import org.bukkit.entity.Player;
import vn.phutcity.PhutCityPlugin;
import vn.phutcity.storage.PlayerDataStore;
import vn.phutcity.storage.PlayerRecord;

public final class EconomyService {
    private final PhutCityPlugin plugin; private final PlayerDataStore data;
    public EconomyService(PhutCityPlugin plugin, PlayerDataStore data) { this.plugin = plugin; this.data = data; }
    public long balance(Player p) { return data.get(p.getUniqueId()).bankBalance(); }
    public boolean transfer(Player from, Player to, long amount) {
        if (amount <= 0 || from.getUniqueId().equals(to.getUniqueId())) return false;
        PlayerRecord a = data.get(from.getUniqueId()), b = data.get(to.getUniqueId());
        synchronized (this) {
            if (a.bankBalance() < amount || Long.MAX_VALUE - b.bankBalance() < amount) return false;
            a.bankBalance(a.bankBalance() - amount); b.bankBalance(b.bankBalance() + amount);
        }
        data.saveAll(); return true;
    }
}
