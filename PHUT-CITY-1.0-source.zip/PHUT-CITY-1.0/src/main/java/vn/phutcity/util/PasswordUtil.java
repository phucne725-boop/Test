package vn.phutcity.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public final class PasswordUtil {
    private static final SecureRandom RANDOM = new SecureRandom();
    private PasswordUtil() {}
    public static String hash(String value) {
        byte[] salt = new byte[16]; RANDOM.nextBytes(salt);
        byte[] digest = digest(salt, value);
        return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(digest);
    }
    public static boolean verify(String value, String encoded) {
        try {
            String[] parts = encoded.split(":", 2);
            byte[] salt = Base64.getDecoder().decode(parts[0]);
            byte[] expected = Base64.getDecoder().decode(parts[1]);
            return MessageDigest.isEqual(expected, digest(salt, value));
        } catch (RuntimeException ex) { return false; }
    }
    private static byte[] digest(byte[] salt, String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt); return md.digest(value.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) { throw new IllegalStateException(ex); }
    }
}
