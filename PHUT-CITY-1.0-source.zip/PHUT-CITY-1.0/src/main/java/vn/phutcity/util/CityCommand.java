package vn.phutcity.util;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import vn.phutcity.PhutCityPlugin;
import vn.phutcity.account.AccountService;
import vn.phutcity.economy.EconomyService;
import vn.phutcity.scoreboard.ScoreboardService;

public final class CityCommand implements CommandExecutor {
    private final Object service; private final String action;
    public CityCommand(Object service, String action) { this.service = service; this.action = action; }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (action.equals("admintool")) {
            if (!sender.hasPermission("phutcity.admin")) { sender.sendMessage(ChatColor.RED + "Khong co quyen."); return true; }
            sender.sendMessage(ChatColor.AQUA + "PHUT CITY Admin: giao dien quan tri day du chua duoc trien khai."); return true;
        }
        if (!(sender instanceof Player p)) { sender.sendMessage("Chi nguoi choi dung duoc lenh nay."); return true; }
        switch (action) {
            case "register" -> { if (args.length != 2) { p.sendMessage("/dangky <mat_khau> <nhap_lai>"); return true; } boolean ok = ((AccountService)service).register(p,args[0],args[1]); p.sendMessage(ok ? "Dang ky thanh cong." : "Dang ky that bai. Mat khau toi thieu 6 ky tu va phai trung nhau."); }
            case "login" -> { if (args.length != 1) { p.sendMessage("/dangnhap <mat_khau>"); return true; } p.sendMessage(((AccountService)service).login(p,args[0]) ? "Dang nhap thanh cong." : "Sai mat khau hoac chua dang ky."); }
            case "lock" -> { if (args.length != 1) { p.sendMessage("/lock <PIN 4-8 so>"); return true; } p.sendMessage(((AccountService)service).lock(p,args[0]) ? "Da LOCK tai khoan." : "PIN khong hop le."); }
            case "unlock" -> { if (args.length != 1) { p.sendMessage("/unlock <PIN>"); return true; } p.sendMessage(((AccountService)service).unlock(p,args[0]) ? "Da mo LOCK." : "PIN sai."); }
            case "money" -> p.sendMessage("So du ngan hang: " + ((EconomyService)service).balance(p) + " P");
            case "pay" -> { if (args.length != 2) { p.sendMessage("/pay <nguoi_choi> <so_tien>"); return true; } Player to = Bukkit.getPlayerExact(args[0]); long amount; try { amount = Long.parseLong(args[1]); } catch (NumberFormatException ex) { p.sendMessage("So tien khong hop le."); return true; } if (to == null) p.sendMessage("Nguoi nhan phai online."); else p.sendMessage(((EconomyService)service).transfer(p,to,amount) ? "Chuyen tien thanh cong." : "Chuyen tien that bai."); }
            case "checkxp" -> { if (!p.hasPermission("phutcity.admin")) p.sendMessage("Khong co quyen."); else if (args.length != 1) p.sendMessage("/checkxp <player>"); else ((ScoreboardService)service).checkXp(p,args[0]); }
        }
        return true;
    }
}
