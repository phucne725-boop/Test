package vn.phutcity.phone;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import vn.phutcity.PhutCityPlugin;
import vn.phutcity.account.AccountService;

public final class LocalChatListener implements Listener {
    private final PhutCityPlugin plugin; private final AccountService accounts;
    public LocalChatListener(PhutCityPlugin plugin, AccountService accounts) { this.plugin = plugin; this.accounts = accounts; }
    @EventHandler public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        if (!accounts.canPlay(sender)) { event.setCancelled(true); return; }
        double radius = plugin.getConfig().getDouble("settings.local-chat-radius", 5);
        event.getRecipients().removeIf(p -> !p.getWorld().equals(sender.getWorld()) || p.getLocation().distanceSquared(sender.getLocation()) > radius * radius);
    }
}
