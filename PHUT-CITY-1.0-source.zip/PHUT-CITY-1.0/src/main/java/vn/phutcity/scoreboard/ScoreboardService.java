package vn.phutcity.scoreboard;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import vn.phutcity.PhutCityPlugin;
import vn.phutcity.storage.PlayerDataStore;
import vn.phutcity.storage.PlayerRecord;

public final class ScoreboardService implements Listener {
    private final PhutCityPlugin plugin; private final PlayerDataStore data;
    public ScoreboardService(PhutCityPlugin plugin, PlayerDataStore data) { this.plugin = plugin; this.data = data; }
    @EventHandler public void onJoin(PlayerJoinEvent e) { update(e.getPlayer()); }
    public void update(Player p) {
        if (!plugin.getConfig().getBoolean("settings.scoreboard-enabled", true)) return;
        PlayerRecord r = data.get(p.getUniqueId());
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("phutcity", "dummy", ChatColor.AQUA + "PHUT CITY");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.getScore(ChatColor.YELLOW + "Ten: " + ChatColor.WHITE + p.getName()).setScore(4);
        obj.getScore(ChatColor.YELLOW + "Nghe: " + ChatColor.WHITE + r.job()).setScore(3);
        obj.getScore(ChatColor.YELLOW + "Cong ty: " + ChatColor.WHITE + r.corporation()).setScore(2);
        obj.getScore(ChatColor.YELLOW + "XP: " + ChatColor.WHITE + r.xp()).setScore(1);
        p.setScoreboard(board);
    }
    public void checkXp(Player sender, String targetName) {
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) { sender.sendMessage(ChatColor.RED + "Nguoi choi phai dang online."); return; }
        sender.sendMessage(ChatColor.GREEN + "XP " + target.getName() + ": " + data.get(target.getUniqueId()).xp());
    }
}
